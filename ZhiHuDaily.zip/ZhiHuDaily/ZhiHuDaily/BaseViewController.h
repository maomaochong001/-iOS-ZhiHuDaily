//
//  ViewController.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/4.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Global.h"
@interface BaseViewController : UIViewController

-(void)HUDShow;
-(void)HUDShow:(NSString*)text;
-(void)HUDShow:(NSString*)text delay:(float)second;
-(void)HUDShow:(NSString*)text delay:(float)second dothing:(BOOL)bDo;
- (void)hudHidden;

- (void)backAction;
@end

