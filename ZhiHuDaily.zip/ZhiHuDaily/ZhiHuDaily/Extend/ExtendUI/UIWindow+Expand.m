//
//  UIWindow+Expand.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/22.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "UIWindow+Expand.h"
#import "LaunchViewController.h"
@implementation UIWindow (Expand)

-(void)showLanuchPage{
    LaunchViewController * launchVC = [[LaunchViewController alloc]init];
    [self addSubview:launchVC.view];
}

@end
