//
//  UIWindow+Expand.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/22.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (Expand)
-(void)showLanuchPage;
@end
