//
//  ThemeItemContentVC.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/10.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ThemeListModel.h"
#import "HomeModel.h"
#import "BaseViewController.h"
@interface ThemeItemContentVC : BaseViewController  

@property(nonatomic,strong)StoryInfo        * themeItem;        
@property(nonatomic,strong)NSMutableArray   * dataArr;
@end
