//
//  ThemeItemContentVC.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/10.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "ThemeItemContentVC.h"

#import "NewsContentModel.h"

@interface ThemeItemContentVC ()<UIScrollViewDelegate,UIWebViewDelegate,UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UIView       * headerView;
@property(nonatomic,strong)UILabel      * recommenderLabel;
@property(nonatomic,strong)UIWebView    * webView;
@property(nonatomic,strong)UITableView  * tableView;
@property(nonatomic,assign)CGFloat      webViewHeight;

@property(nonatomic,strong)NewsContentModel * contentModel;
@end

@implementation ThemeItemContentVC

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    [SVProgressHUD dismiss];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    // Do any additional setup after loading the view.
    [self initSubViews];
    
    [self getData];
    NSLog(@"主题日报详情页");

}

- (void)getData{
    [self HUDShow];
    [HttpOperation getRequestWithURL:[NSString stringWithFormat:@"news/%ld",(long)self.themeItem.id] parameters:nil className:@"NewsContentModel" success:^(id responseObject) {
        self.contentModel = (NewsContentModel *)responseObject;
        
        [self setUI];
    } failure:nil];
}

- (void)setUI{
    
    [self.view addSubview:_webView];
    if (self.contentModel.recommenders.count > 0) {
        [self.webView setFrame:CGRectMake(0, 70, kScreenWidth, kScreenHeight-70-43)];
        [self.view addSubview:self.headerView];
        _headerView.hidden = NO;
        
        for (UIImageView * imageView in self.headerView.subviews) {
            if ([imageView isKindOfClass:[UIImageView class]]) {
                [imageView removeFromSuperview];
            }
            
        }
        
        for (int i = 0; i<self.contentModel.recommenders.count; i++) {
            Recommender * recommenderInfo = [self.contentModel.recommenders objectAtIndex:i];
            UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(_recommenderLabel.right+10+i*(30+10), 0, 30, 30)];
            [imageView setCenterY:_recommenderLabel.centerY];
            [imageView sd_setImageWithURL:[NSURL URLWithString:recommenderInfo.avatar] placeholderImage:[UIImage imageNamed:@"Comment_Avatar"]];
            [self.headerView addSubview:imageView];
            UIImageView * maskView = [[UIImageView alloc]initWithFrame:CGRectMake(_recommenderLabel.right+10+i*(30+10), 0, 30, 30)];
            [maskView setCenterY:_recommenderLabel.centerY];
            [maskView setImage:[UIImage imageNamed:@"Comment_Avatar_Mask"]];
            [self.headerView addSubview:maskView];
        }

    }
    else{
         _headerView.hidden = YES;
        [self.webView setFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight-43)];
    }
    
    if (self.contentModel.body && self.contentModel.body.length > 0) {
        [_webView loadHTMLString:[NSString stringWithFormat:@"<html><head><link rel=\"stylesheet\" href=%@></head><body>%@</body></html>",self.contentModel.css[0],self.contentModel.body] baseURL:nil];
    }else {
        NSString *desturl = [NSString stringWithFormat:@"http://daily.zhihu.com/story/%ld", (long)self.contentModel.id];
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:desturl]]];
    }
    
}

#pragma mark - web delegate
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self hudHidden];
    //获取webView的内容高度
    const CGFloat defaultWebViewHeight = 22.0;
    //reset webview size
    CGRect originalFrame = webView.frame;
    webView.frame = CGRectMake(originalFrame.origin.x, originalFrame.origin.y, 320, defaultWebViewHeight);
    CGSize actualSize = [webView sizeThatFits:CGSizeZero];
    //获取webView的内容高度
    _webViewHeight = actualSize.height;
    
    
    
   if (self.contentModel.recommenders.count > 0)
   {
       [self.tableView setFrame:CGRectMake(0, 70, kScreenWidth, kScreenHeight-70-43)];
   }
   else
   {
       [self.tableView setFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight-43)];
   }
    
    [self.tableView reloadData];
    
    self.tableView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        StoryInfo * storyInfo = (StoryInfo *)[StoryInfo findFirstByCriteria:[NSString stringWithFormat:@"WHERE id=%d",self.themeItem.id]];
        //这里比较蛋疼的是 获取到的storyInfo不能直接更新进数据库，只能重新创建一个storyInfo2，赋值给新创建的storyInfo2，然后storyInfo2才能更新近数据库
        //只是为了标记readAlready为已读
        if (storyInfo) {
            StoryInfo * storyInfo2 = [[StoryInfo alloc]init];
            storyInfo2.pk = storyInfo.pk;
            storyInfo2.title = storyInfo.title;
            storyInfo2.ga_prefix = storyInfo.ga_prefix;
            storyInfo2.images = storyInfo.images;
            storyInfo2.multipic = storyInfo.multipic;
            storyInfo2.type = storyInfo.type;
            storyInfo2.id = storyInfo.id;
            storyInfo2.readAlready = 1;
            [storyInfo2 update];
        }
        
    });
}
//不让点击网页里的链接
- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType {
    
    if(navigationType==UIWebViewNavigationTypeLinkClicked)//判断是否是点击链接
        
    {
        return NO;
    }
    
    else{
        return YES;
    }
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        return _webViewHeight;
    }
    else{
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *SimpleTableIdentifier = @"SimpleTableIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
                             SimpleTableIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                       reuseIdentifier: SimpleTableIdentifier];
    }
    if (indexPath.row == 0)
    {
        [cell.contentView addSubview:self.webView];
        [self.webView setFrame:CGRectMake(0, 0, kScreenWidth, _webViewHeight)];
    }
    return cell;
}



- (UIView *)headerView{
    if (!_headerView) {
        _headerView = ({
            UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 70)];
            view.clipsToBounds = YES;
            [self.view addSubview:view];
            view;
        });
        
        ({
            UIView * lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 69.5, kScreenWidth, 0.5)];
            lineView.backgroundColor = [UIColor colorWithRed:0.886 green:0.886 blue:0.886 alpha:1.00];
            [_headerView addSubview:lineView];
        });
        _recommenderLabel = ({
            UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 60, 30)];
            label.font = [UIFont systemFontOfSize:14];
            label.textColor = [UIColor darkGrayColor];
            label.textAlignment = NSTextAlignmentLeft;
            [_headerView addSubview:label];
            [label setCenterY:20+(self.headerView.height-20)/2];
            [label setLeft:10];
            label.text =@"推荐者";
            label;
        });
    }
    return _headerView;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.f, _headerView.bottom, kScreenWidth, kScreenHeight-60)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsHorizontalScrollIndicator = YES;
        _tableView.separatorStyle = UITableViewCellSelectionStyleNone;

    }
    return _tableView;
}

- (void)initSubViews{
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self.view addSubview:self.tableView];
    self.tableView.hidden = YES;
    _webView = ({
        UIWebView * webView = [[UIWebView alloc]init];
        webView.backgroundColor = [UIColor whiteColor];
        webView.scrollView.showsHorizontalScrollIndicator=NO;
        webView.scrollView.scrollEnabled = NO;
        [webView.scrollView setBounces:YES];
        webView.delegate = self;
        
        webView;
    });
    
    UIView * toolBar = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, kScreenHeight-43, kScreenWidth, 43)];
        view.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:view];
        view;
    });
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(0, 0, kScreenWidth/5, 43)];
        [button setImage:[UIImage imageNamed:@"News_Navigation_Arrow"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        [toolBar addSubview:button];
    });
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(kScreenWidth/5, 0,kScreenWidth/5, 43)];
        [button setImage:[UIImage imageNamed:@"News_Navigation_Next"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(nextStoryAction:) forControlEvents:UIControlEventTouchUpInside];
        [toolBar addSubview:button];
    });
    
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake((kScreenWidth/5)*2, 0, kScreenWidth/5, 43)];
        [button setImage:[UIImage imageNamed:@"News_Navigation_Voted"] forState:UIControlStateNormal];
        [toolBar addSubview:button];
    });
    
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake((kScreenWidth/5)*3, 0, kScreenWidth/5, 43)];
        [button setImage:[UIImage imageNamed:@"News_Navigation_Share"] forState:UIControlStateNormal];
        [toolBar addSubview:button];
    });
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake((kScreenWidth/5)*4, 0, kScreenWidth/5, 43)];
        
        [button setImage:[UIImage imageNamed:@"News_Navigation_Comment"] forState:UIControlStateNormal];
        [toolBar addSubview:button];
    });
    
    
}

- (void)nextStoryAction:(id)sender {
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow: 0  inSection:0]  atScrollPosition:UITableViewScrollPositionTop animated:YES];
    
    NSInteger  index = [self.dataArr indexOfObject:self.themeItem];
    if (index+1 < self.dataArr.count) {
         self.themeItem = [self.dataArr objectAtIndex:index+1];
        [self getData];
    }
    
   
}

- (void)backAction{
    [SVProgressHUD dismiss];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"ThemeItemVCBackToHomeVC" object:nil];
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
