//
//  ThemeListModel.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/7.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface EditorInfo : NSObject
{
    NSString        * avatar;
    NSString        * name;
    NSInteger       id;
    NSString        * url;
    NSString        * bio;
}

@property(nonatomic, strong) NSString       * avatar;
@property(nonatomic, strong) NSString       * name;
@property(assign, readonly) NSInteger      id;
@property(nonatomic, strong) NSString       * url;
@property(nonatomic, strong) NSString       * bio;
@end

/*
@interface ThemeItem : NSObject
{
    NSString        * title;
    NSInteger       type;
    NSInteger       id;
    NSMutableArray  * images;
}

@property(nonatomic, strong) NSString       * title;
@property(assign, readonly) NSInteger      type;
@property(assign, readonly) NSInteger      id;
@property(nonatomic, strong) NSMutableArray  * images;
@end
 */


@interface ThemeListModel : NSObject
{
    NSString        * name;
    NSString        * image;
    NSString        * image_source;
    NSString        * description;
    NSString        * background;
    NSString        * color;
    NSMutableArray  * stories;
    NSMutableArray  * editors;
}

@property(nonatomic,strong) NSString *name;
@property(nonatomic,strong) NSString *image;
@property(nonatomic,strong) NSString *image_source;
@property(nonatomic,strong) NSString *description;
@property(nonatomic,strong) NSString *background;
@property(nonatomic,strong) NSString *color;

@property(nonatomic,strong) NSMutableArray *stories;
@property(nonatomic,strong) NSMutableArray *editors;
@end
