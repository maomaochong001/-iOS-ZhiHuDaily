//
//  ThemeListModel.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/7.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "ThemeListModel.h"
#import "NSDictionary+JSON.h"
#import "HomeModel.h"
@implementation EditorInfo
@synthesize avatar;
@synthesize name;
@synthesize id;
@synthesize url;
@synthesize bio;
@end

@implementation ThemeListModel
@synthesize name;
@synthesize image;
@synthesize image_source;
@synthesize description;
@synthesize background;
@synthesize color;
@synthesize stories;
@synthesize editors;

- (NSMutableArray *)stories {
    for (int i = 0; i < stories.count; i++) {
        if([[stories objectAtIndex:i] class] != [StoryInfo class]) {
            NSDictionary * _dic = (NSDictionary *)[stories objectAtIndex:i];
            [stories replaceObjectAtIndex:i withObject:[_dic dictionaryTo:NSClassFromString(@"StoryInfo")]];
        }
    }
    return stories;
}

- (NSMutableArray *)editors {
    for (int i = 0; i < editors.count; i++) {
        if([[editors objectAtIndex:i] class] != [EditorInfo class]) {
            NSDictionary * _dic = (NSDictionary *)[editors objectAtIndex:i];
            [editors replaceObjectAtIndex:i withObject:[_dic dictionaryTo:NSClassFromString(@"EditorInfo")]];
        }
    }
    return editors;
}

@end
