//
//  ThemeItemCell.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/7.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "ThemeItemCell.h"
@interface ThemeItemCell()


@property (nonatomic,strong) StoryInfo * themeItem;
@end

@implementation ThemeItemCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        // label
        _label = ({
            UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, kScreenWidth-10-72-20, 44)];
            label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            label.textColor = [UIColor blackColor];
            label.font = [UIFont boldSystemFontOfSize:16];
            label.numberOfLines = 0;
            [self.contentView addSubview:label];
            label;
        });
        
        _imgView = ({
            UIImageView  * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(kScreenWidth-10-72, 14,72, 59)];
            [self.contentView addSubview:imageView];
            imageView;
        });
        
       _imgView.hidden = YES;
        
    }
    return self;
}


- (void)settingData:(StoryInfo *)themeItem{
    self.themeItem = themeItem;
    self.label.text = themeItem.title;
    if (themeItem.images.count > 0) {
        _imgView.hidden = NO;
        NSString *imageURL = [themeItem.images firstObject];
        [self.imgView sd_setImageWithURL:[NSURL URLWithString:imageURL]];
        [_label setWidth:kScreenWidth-10-72-20];
    }
    else {
        _imgView.hidden = YES;
        [_label setWidth:kScreenWidth-20];
    }
    StoryInfo * sInfo2 = [StoryInfo findFirstByCriteria:[NSString stringWithFormat:@"WHERE id=%d",themeItem.id]];
    if (sInfo2.readAlready==1) {
        //已经读过此条
        self.label.textColor = [UIColor colorWithRed:0.404 green:0.404 blue:0.404 alpha:1.00];
    }
    else{
        self.label.textColor = [UIColor colorWithRed:0.000 green:0.000 blue:0.000 alpha:1.00];
    }
}


@end
