//
//  Global.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/4.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "Global.h"

@implementation Global

@end
