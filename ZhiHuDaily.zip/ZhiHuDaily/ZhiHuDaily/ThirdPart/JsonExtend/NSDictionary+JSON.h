//
//  NSDictionary+JSON.h
//  JSONTest
//
//  Created by Jay on 1/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import "NSArray+JSON.h"

@interface NSDictionary (JSON)

- (id) dictionaryTo:(Class) responseType;
@end
