//
//  ThemeItemModel.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/2/23.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThemeItemDetailModel : NSObject
{
    NSInteger         color;
    NSString        * thumbnail;//缩略图
    NSString        * description;//描述
    NSInteger         id;
    NSString        * name;
    
}

@property(nonatomic, assign) NSInteger         color;
@property(nonatomic, strong) NSString        * thumbnail;
@property(nonatomic, strong) NSString        * description;
@property(nonatomic, assign) NSInteger         id;
@property(nonatomic, strong) NSString        * name;

@end


@interface ThemeItemModel : NSObject
{
    NSInteger         limit;
    NSMutableArray  * subscribed;//已订阅主题
    NSMutableArray  * others;//主题数组
    
}

@property(nonatomic, assign) NSInteger         limit;
@property(nonatomic, strong) NSMutableArray  * subscribed;
@property(nonatomic, strong) NSMutableArray  * others;

@end


