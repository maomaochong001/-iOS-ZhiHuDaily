//
//  ThemeItemModel.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/2/23.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "ThemeItemModel.h"
#import "NSDictionary+JSON.h"

@implementation ThemeItemDetailModel

@synthesize color;
@synthesize thumbnail;
@synthesize description;
@synthesize id;
@synthesize name;

@end


@implementation ThemeItemModel

@synthesize limit;
@synthesize subscribed;
@synthesize others;

- (NSMutableArray *)others {
    for (int i = 0; i < others.count; i++) {
        if([[others objectAtIndex:i] class] != [ThemeItemDetailModel class]) {
            NSDictionary * _dic = (NSDictionary *)[others objectAtIndex:i];
            [others replaceObjectAtIndex:i withObject:[_dic dictionaryTo:NSClassFromString(@"ThemeItemDetailModel")]];
        }
    }
    return others;
}

@end
