//
//  MenuCell.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/2/25.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ThemeItemModel.h"
@interface MenuCell : UITableViewCell

@property (nonatomic,strong) UIImageView    * imgViewLeft;
@property (nonatomic,strong) UILabel        * label;
@property (nonatomic,strong) UIImageView    * imgViewRight;

- (void)settingData:(ThemeItemDetailModel *)themeItemDetail isFirstRow:(BOOL)FirstRow;
@end
