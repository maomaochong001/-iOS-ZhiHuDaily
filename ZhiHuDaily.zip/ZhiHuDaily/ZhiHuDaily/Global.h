//
//  Global.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/4.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJRefresh.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "HttpOperation.h"
#import "NSDateFormatter+Extension.h"

#import "UIView+Extension.h"
#import "SVProgressHUD.h"

@interface Global : NSObject
//判断设备类型
#define iPhone4 ([UIScreen mainScreen].bounds.size.height == 480)
#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone6 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? (CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size)) : NO)
#define iPhone6plus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? (CGSizeEqualToSize(CGSizeMake(1125, 2001), [[UIScreen mainScreen] currentMode].size) || CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size)) : NO)

#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define kScreenBounds [UIScreen mainScreen].bounds
#define kWidth(R) (R)*(kScreenWidth)/320
#define kHeight(R) (iPhone4?((R)*(kScreenHeight)/480):((R)*(kScreenHeight)/568))

#define BASEURL @"http://news-at.zhihu.com/api/4"

#define kNavigationBarColor [UIColor colorWithRed:0.231 green:0.549 blue:0.835 alpha:1.0f];
#define kAppdelegate (AppDelegate *)[UIApplication sharedApplication].delegate;
#define AnimateDuration         0.3
@end
