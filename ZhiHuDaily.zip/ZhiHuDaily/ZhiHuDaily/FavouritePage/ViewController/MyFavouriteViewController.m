//
//  MyFavouriteViewController.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/5/20.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "MyFavouriteViewController.h"
#import "NewsContentViewController.h"

#import "ThemeItemCell.h"

@interface MyFavouriteViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UIView           * navBarView;
@property(nonatomic,strong)UIButton         * editButton;
@property(nonatomic,strong)UITableView      * tableView;

@property(nonatomic,strong)NSMutableArray   * fav_ListArray;

@end

@implementation MyFavouriteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initSubViews];
    [self getData];
}

- (void)getData{
    NSArray * dataArray = [StoryInfo findByCriteria:[NSString stringWithFormat:@"WHERE favourite=1"]];
    if (dataArray) {
        _fav_ListArray = [NSMutableArray arrayWithArray:dataArray];
        [self.tableView reloadData];
        if ([dataArray count]>0) {
            _editButton.hidden = NO;
        }else{
            _editButton.hidden = YES;
        }
    }
    
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _fav_ListArray.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
        static NSString *identifier = @"ThemeItemCell";
        ThemeItemCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil) {
            cell = [[ThemeItemCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] ;
        }
        
        StoryInfo * themeItem = [_fav_ListArray objectAtIndex:indexPath.row];
        [cell settingData:themeItem];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
        
        NewsContentViewController * newsContentVC = [[NewsContentViewController alloc]init];
        StoryInfo * stroryInfo                    = [_fav_ListArray objectAtIndex:indexPath.row];
        newsContentVC.stroryInfo                  = stroryInfo;
        newsContentVC.NewsContentDisplayMode      = MyFavContentViewDisplayMode;
        [self.navigationController pushViewController:newsContentVC animated:YES];
    
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleDelete;
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @"不再收藏";
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [_fav_ListArray removeObjectAtIndex:indexPath.row];
        [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        // 更新到数据库中
        if (_fav_ListArray.count > indexPath.row)
        {
            StoryInfo * sInfo = [_fav_ListArray objectAtIndex:indexPath.row];
            StoryInfo * storyInfo2 = [[StoryInfo alloc]init];
            storyInfo2.pk = sInfo.pk;
            storyInfo2.title = sInfo.title;
            storyInfo2.ga_prefix = sInfo.ga_prefix;
            storyInfo2.images = sInfo.images;
            storyInfo2.multipic = sInfo.multipic;
            storyInfo2.type = sInfo.type;
            storyInfo2.id = sInfo.id;
            storyInfo2.readAlready = sInfo.readAlready;
            storyInfo2.favourite = 0;
            [storyInfo2 update];
        }
        if ([_fav_ListArray count]>0) {
            _editButton.hidden = NO;
        }else{
            _editButton.hidden = YES;
        }
    }
    
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, kScreenWidth, kScreenHeight-64)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsHorizontalScrollIndicator = YES;
        _tableView.rowHeight = kRowHeight;
        [self.view addSubview:_tableView];
        //隐藏空白cell分割线
        _tableView.tableFooterView = [[UIView alloc]init];
    }
    return _tableView;
}

- (void)initSubViews{
    _navBarView = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 64)];
        view.backgroundColor = [UIColor colorWithRed:0.231 green:0.549 blue:0.835 alpha:1.0];
        [self.view addSubview:view];
        view;
    });
    //标题
    ({
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 90, 25)];
        label.attributedText = [[NSAttributedString alloc] initWithString:@"我的收藏" attributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:18] ,NSForegroundColorAttributeName:[UIColor whiteColor]}];
        label.textAlignment = NSTextAlignmentCenter;
        [label sizeToFit];
        [_navBarView addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker * make) {
            make.centerY.equalTo(_navBarView.mas_top).offset(40);
            make.centerX.equalTo(_navBarView.mas_centerX);
        }];
    });
    //返回按钮
    ({
        UIButton * button = [UIButton buttonWithType:0];
        [button setFrame:CGRectMake(5, 20, 44, 44)];
        [button setImage:[UIImage imageNamed:@"Back_White"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(backToHomeVC) forControlEvents:UIControlEventTouchUpInside];
        [_navBarView addSubview:button];
    });
    
    //编辑按钮
   _editButton = ({
       UIButton * button = [UIButton buttonWithType:0];
        [button setFrame:CGRectMake(kScreenWidth-60-5, 25, 60, 30)];
        [button setTitle:@"编辑" forState:UIControlStateNormal];
        [button.titleLabel setFont:[UIFont systemFontOfSize:15]];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(editButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [_navBarView addSubview:button];
        button;
    });
    _editButton.hidden = YES;
    
}

/**
 *  编辑按钮点击
 */
- (void)editButtonClick{
    [self.tableView setEditing:!_editButton.selected];
    _editButton.selected = !_editButton.selected;
}

- (void)backToHomeVC{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
