//
//  WebImgScrollView.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/5/11.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebImgScrollView : UIView

@property(nonatomic, copy) NSString * imgUrl;

+ (WebImgScrollView *)showImgWithUrl:(NSString *)urlString;

@end
