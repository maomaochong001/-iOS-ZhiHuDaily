//
//  NewsContentModel.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/29.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "NewsContentModel.h"
#import "NSDictionary+JSON.h"
@implementation Theme
@synthesize thumbnail;
@synthesize name;
@synthesize id;
@end


@implementation Recommender
@synthesize  avatar;
@end


@implementation NewsContentModel
@synthesize body;
@synthesize image_source;
@synthesize title;
@synthesize image;
@synthesize share_url;
@synthesize js;
@synthesize ga_prefix;
@synthesize type;
@synthesize id;
@synthesize css;

@synthesize recommenders;
@synthesize theme;

- (NSMutableArray *)recommenders {
    for (int i = 0; i < recommenders.count; i++) {
        if([[recommenders objectAtIndex:i] class] != [Recommender class]) {
            NSDictionary * _dic = (NSDictionary *)[recommenders objectAtIndex:i];
            [recommenders replaceObjectAtIndex:i withObject:[_dic dictionaryTo:NSClassFromString(@"Recommender")]];
        }
    }
    return recommenders;
}
@end
