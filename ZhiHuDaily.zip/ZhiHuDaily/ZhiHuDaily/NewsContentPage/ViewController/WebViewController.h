//
//  WebViewController.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/5/12.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "BaseViewController.h"

@interface WebViewController : BaseViewController

- (instancetype)initWithNSString:(NSString *)str;

@end
