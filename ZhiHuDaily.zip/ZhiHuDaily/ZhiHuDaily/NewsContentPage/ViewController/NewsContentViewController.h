//
//  NewsContentViewController.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/18.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
#import "BaseViewController.h"

@protocol NewsContentVCDelegate <NSObject>

- (void)backWithDataArr:(NSMutableArray *)dataArr;

@end

@interface NewsContentViewController : BaseViewController

@property(nonatomic,assign) id<NewsContentVCDelegate> delegate;
@property(nonatomic,strong)StoryInfo        * stroryInfo;
@property(nonatomic,strong)NSMutableArray   * dataArr;
@property(nonatomic,assign)NSInteger          sectionIndex;
@property(nonatomic,assign)NSInteger          rowIndex;
@end
