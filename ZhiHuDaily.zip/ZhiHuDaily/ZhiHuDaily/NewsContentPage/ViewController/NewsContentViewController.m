//
//  NewsContentViewController.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/18.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "NewsContentViewController.h"

#import "DetailHeaderView.h"
#import "DetailFooterView.h"

#import "NewsContentModel.h"


@interface NewsContentViewController ()<UIScrollViewDelegate,UIWebViewDelegate,UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UIView           * headerView;
@property(nonatomic,strong)UIImageView      * imageView;
@property(nonatomic,strong)UILabel          * tittleLab;
@property(nonatomic,strong)UILabel          * imageSourceLab;
@property(nonatomic,strong)UIWebView        * webView;
@property(nonatomic,strong)UITableView      * tableView;
@property(nonatomic,assign)CGFloat          webViewHeight;
@property(nonatomic,strong)DetailHeaderView * headerLoadView;
@property(nonatomic,strong)DetailFooterView * footerLoadView;
@property(nonatomic,strong)UILabel          * firstLabel;

@property(nonatomic,strong)NewsContentModel * contentModel;
@end

@implementation NewsContentViewController
- (void)dealloc{
    
    [self.tableView removeObserver:self.footerLoadView forKeyPath:@"contentOffset"];
    [self.tableView removeObserver:self.headerLoadView forKeyPath:@"contentOffset"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    [SVProgressHUD dismiss];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    //
    // Do any additional setup after loading the view.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NewsContentVCBackToHomeVC:) name:@"NewsContentVCBackToHomeVC" object:nil];
    [self initSubViews];
    
    [self getData];
    NSLog(@"日报详情页");

}

- (void)getData{
    [self HUDShow];
    [HttpOperation getRequestWithURL:[NSString stringWithFormat:@"news/%ld",(long)self.stroryInfo.id] parameters:nil className:@"NewsContentModel" success:^(id responseObject) {
        self.contentModel = (NewsContentModel *)responseObject;
        
        [self setUI];
    } failure:nil];
}

- (void)setUI{
    [_imageView sd_setImageWithURL:[NSURL URLWithString:self.contentModel.image]];
    NSAttributedString * attString = [[NSAttributedString alloc] initWithString:self.contentModel.title attributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:21],NSForegroundColorAttributeName:[UIColor whiteColor]}];
    CGSize size = [attString boundingRectWithSize:CGSizeMake(kScreenWidth-30, 60) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading context:nil].size;
    _tittleLab.frame = CGRectMake(15, _headerView.frame.size.height-20-size.height, kScreenWidth-30, size.height);
    _tittleLab.attributedText = attString;
    _imageSourceLab.text = [NSString stringWithFormat:@"图片：%@",self.contentModel.image_source];
   
    [_webView loadHTMLString:[NSString stringWithFormat:@"<html><head><link rel=\"stylesheet\" href=%@></head><body>%@</body></html>",self.contentModel.css[0],self.contentModel.body] baseURL:nil];

    if (self.sectionIndex == 0 && self.rowIndex == 0) {
        [_imageView addSubview:self.firstLabel];
        self.firstLabel.top = 20;
        self.firstLabel.hidden      = NO;
        self.headerLoadView.hidden  = YES;
    }else{
        [_imageView addSubview:self.headerLoadView];
        self.headerLoadView.top = 15;
        self.firstLabel.hidden      = YES;
        self.headerLoadView.hidden  = NO;
    }

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    CGFloat offSetY = scrollView.contentOffset.y;
    //NSLog(@"offSetY:%f",offSetY);
    
    if ([scrollView isEqual:self.tableView]) {
        //向下拉
        if (-offSetY <=80&&-offSetY>=0) {
            _headerView.frame = CGRectMake(0, -40+(-offSetY/2), kScreenWidth, 260+(-offSetY/2));
            //标题和图片源Label也往下移
            [_imageSourceLab setMj_y:240+(-offSetY/2)];
            [_tittleLab setMj_y:240+(-offSetY/2)-_tittleLab.mj_h];
        }
        else if (-offSetY>80){
            //限制最大偏移量
            self.tableView.contentOffset = CGPointMake(0, -80);
        }
        //向上拉
        else if(offSetY<=300){
            _headerView.frame = CGRectMake(0, -40-offSetY, kScreenWidth, 260);
            
        }
        
        //顶步状态栏
        if (offSetY<=200) {
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
        }
        else{
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
        }
        
    }
}

#pragma mark - web delegate
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self hudHidden];
    const CGFloat defaultWebViewHeight = 22.0;
    //reset webview size
    CGRect originalFrame = webView.frame;
    webView.frame = CGRectMake(originalFrame.origin.x, originalFrame.origin.y, 320, defaultWebViewHeight);
    CGSize actualSize = [webView sizeThatFits:CGSizeZero];
    //获取webView的内容高度
    _webViewHeight = actualSize.height;
    //获取webView的内容高度  这个方法在第二次加载网页时候获取到的网页高度不会变化，不准确
    //_webViewHeight = [[_webView stringByEvaluatingJavaScriptFromString:@"document.height"]floatValue];
    
    [self.tableView reloadData];
    self.tableView.hidden = NO;
    self.footerLoadView.load = YES;
     self.headerLoadView.load = YES;
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        StoryInfo * sInfo = (StoryInfo *)[StoryInfo findFirstByCriteria:[NSString stringWithFormat:@"WHERE id=%d",self.stroryInfo.id]];
        //这里比较蛋疼的是 获取到的storyInfo不能直接更新进数据库，只能重新创建一个storyInfo2，赋值给新创建的storyInfo2，然后storyInfo2才能更新近数据库
        //只是为了标记readAlready为已读
        if (sInfo) {
            StoryInfo * storyInfo2 = [[StoryInfo alloc]init];
            storyInfo2.pk = sInfo.pk;
            storyInfo2.title = sInfo.title;
            storyInfo2.ga_prefix = sInfo.ga_prefix;
            storyInfo2.images = sInfo.images;
            storyInfo2.multipic = sInfo.multipic;
            storyInfo2.type = sInfo.type;
            storyInfo2.id = sInfo.id;
            storyInfo2.readAlready = 1;
            [storyInfo2 update];
        }
        
    //});
}
//不让点击网页里的链接
- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType {
    
    if(navigationType==UIWebViewNavigationTypeLinkClicked)//判断是否是点击链接
        
    {
        return NO;
    }
    
    else{
        return YES;
    }
}



- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 20, kScreenWidth, kScreenHeight-20-43)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsHorizontalScrollIndicator = YES;
         _tableView.separatorStyle = UITableViewCellSelectionStyleNone;
        [_tableView addSubview:self.footerLoadView];
    }
    return _tableView;
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        return _webViewHeight;
    }
    else{
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *SimpleTableIdentifier = @"SimpleTableIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
                             SimpleTableIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier: SimpleTableIdentifier];
    }
    if (indexPath.row == 0)
    {
        [cell.contentView addSubview:self.webView];
        [self.webView setFrame:CGRectMake(0, 0, kScreenWidth, _webViewHeight)];
        self.footerLoadView.top = _webViewHeight + 15;
        
    }
    return cell;
}

- (void)initSubViews{
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self.view addSubview:self.tableView];
    self.tableView.hidden = YES;
    
    _webView = ({
        UIWebView * webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 20, kScreenWidth, kScreenHeight-20-43)];
        //webView.scrollView.delegate = self;
        webView.backgroundColor = [UIColor whiteColor];
        webView.scrollView.showsHorizontalScrollIndicator=NO;
        [webView.scrollView setBounces:YES];
        webView.scrollView.scrollEnabled = NO;
        webView.delegate = self;
        [self.view addSubview:webView];
        
        webView;
    });

    _headerView = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, -40, kScreenWidth, 260)];
        view.clipsToBounds = YES;
        [self.view addSubview:view];
        view;
    });
    
    _imageView = ({
        UIImageView * imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 300)];
        imgView.contentMode = UIViewContentModeScaleAspectFill;
        [_headerView addSubview:imgView];
        imgView;
    });

    _tittleLab = ({
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectZero];
        label.numberOfLines = 0;
        [_headerView addSubview:label];
        label;
    });
    
    _imageSourceLab = ({
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(15, 240, kScreenWidth-30, 20)];
        label.textAlignment = NSTextAlignmentRight;
        label.font = [UIFont systemFontOfSize:10];
        label.textColor = [UIColor lightGrayColor];
        [_headerView addSubview:label];
        label;
    });
    
    UIView * toolBar = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, kScreenHeight-43, kScreenWidth, 43)];
        view.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:view];
        view;
    });
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(0, 0, kScreenWidth/5, 43)];
        [button setImage:[UIImage imageNamed:@"News_Navigation_Arrow"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
        [toolBar addSubview:button];
    });
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(kScreenWidth/5, 0,kScreenWidth/5, 43)];
        [button setImage:[UIImage imageNamed:@"News_Navigation_Next"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(nextStoryAction:) forControlEvents:UIControlEventTouchUpInside];
        [toolBar addSubview:button];
    });
    
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake((kScreenWidth/5)*2, 0, kScreenWidth/5, 43)];
        [button setImage:[UIImage imageNamed:@"News_Navigation_Voted"] forState:UIControlStateNormal];
        [toolBar addSubview:button];
    });
    
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake((kScreenWidth/5)*3, 0, kScreenWidth/5, 43)];
        [button setImage:[UIImage imageNamed:@"News_Navigation_Share"] forState:UIControlStateNormal];
        [toolBar addSubview:button];
    });
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake((kScreenWidth/5)*4, 0, kScreenWidth/5, 43)];
        
        [button setImage:[UIImage imageNamed:@"News_Navigation_Comment"] forState:UIControlStateNormal];
        [toolBar addSubview:button];
    });
    
    
}

- (void)backAction:(id)sender
{
    [self backAction];
    if ([self.delegate respondsToSelector:@selector(backWithDataArr:)])
    {
        [self.delegate backWithDataArr:self.dataArr];
    }
    
}

#pragma mark - 如果是滑动返回 需要发通知 这里接收到通知以后传值过去
- (void)NewsContentVCBackToHomeVC:(NSNotification *)noti
{
    if ([self.delegate respondsToSelector:@selector(backWithDataArr:)])
    {
        [self.delegate backWithDataArr:self.dataArr];
    }
}

- (void)lastStoryAction:(id)sender {
    if (self.sectionIndex == 0 && self.rowIndex == 0) {
        return;
    }
    self.headerLoadView.load = NO;
    
    if (self.rowIndex>0) {
        self.rowIndex--;
    }
    else if(self.rowIndex == 0){
        self.sectionIndex--;
        HomeModel * homemodel = [self.dataArr objectAtIndex:self.sectionIndex];
        self.rowIndex = [homemodel.stories count]-1;
    }
    
    HomeModel * homemodel = [self.dataArr objectAtIndex:self.sectionIndex];
     StoryInfo * sInfo = [homemodel.stories objectAtIndex:self.rowIndex];
    
    self.stroryInfo = sInfo;
    [self getData];
}


- (void)nextStoryAction:(id)sender {
    self.footerLoadView.load = NO;
    
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow: 0  inSection:0]  atScrollPosition:UITableViewScrollPositionTop animated:YES];
    
    HomeModel * homemodel = [self.dataArr objectAtIndex:self.sectionIndex];
    
    //如果是已有的最后一条数据
    if (self.rowIndex+1 == homemodel.stories.count && self.sectionIndex+1 == self.dataArr.count) {
        //这里请求下面的新数据
        [self HUDShow];
        [HttpOperation getRequestWithURL:[NSString stringWithFormat:@"news/before/%@",homemodel.date] parameters:nil className:@"HomeModel" success:^(id responseObject) {
            HomeModel * get_HomeModel = (HomeModel *)responseObject;
            [self.dataArr addObject:get_HomeModel];
            
            for (int i=0; i<get_HomeModel.stories.count; i++) {
                //先查询有没有这条数据
                StoryInfo * sInfo = [get_HomeModel.stories objectAtIndex:i];
                dispatch_async(dispatch_get_global_queue(0, 0), ^{
                    StoryInfo * sInfo2 = [StoryInfo findFirstByCriteria:[NSString stringWithFormat:@"WHERE id=%d",sInfo.id]];
                    //没有的话保存进数据库
                    if (!sInfo2) {
                        [sInfo save];
                    }
                });
            }
            
            [self hudHidden];
            
            self.rowIndex = 0;
            self.sectionIndex++;
            HomeModel * homemodel2 = [self.dataArr objectAtIndex:self.sectionIndex];
            StoryInfo * sInfo = [homemodel2.stories objectAtIndex:self.rowIndex];
            self.stroryInfo = sInfo;
            
            [self getData];
            
        } failure:nil];
        return;
    }
    
    //如果是一个区的最后一行
    if (self.rowIndex+1 == homemodel.stories.count && self.sectionIndex+1 < self.dataArr.count) {
        self.rowIndex = 0;
        self.sectionIndex++;
        if (self.sectionIndex<self.dataArr.count && self.rowIndex<homemodel.stories.count) {
            
            HomeModel * homemodel2 = [self.dataArr objectAtIndex:self.sectionIndex];
            StoryInfo * sInfo = [homemodel2.stories objectAtIndex:self.rowIndex];
            self.stroryInfo = sInfo;
            
           [self getData];
        }
        return;
    }
    //在当前的区，还有下一行，直接加载下一行
    if (self.rowIndex < homemodel.stories.count) {
        self.rowIndex++;
        if (self.sectionIndex<self.dataArr.count && self.rowIndex<homemodel.stories.count) {
            
            HomeModel * homemodel2 = [self.dataArr objectAtIndex:self.sectionIndex];
            StoryInfo * sInfo = [homemodel2.stories objectAtIndex:self.rowIndex];
            self.stroryInfo = sInfo;
            
            [self getData];
        }
        return;
    }
    
}
- (UILabel *)firstLabel{
    if (_firstLabel == nil) {
        UILabel *label = [[UILabel alloc] init];
        label.text = @"这已经是第一篇了";
        [label sizeToFit];
        label.textColor = [UIColor colorWithRed:0.749 green:0.749 blue:0.749 alpha:1.00];
        label.font = [UIFont systemFontOfSize:14.f];
        label.centerX = kScreenWidth/2;
        label.textAlignment = NSTextAlignmentCenter;
        _firstLabel = label;
    }
    return _firstLabel;
}
#pragma mark - 加载上一篇
- (DetailHeaderView *)headerLoadView{
    if (_headerLoadView == nil) {
        _headerLoadView = [DetailHeaderView attachObserveToScrollView:self.tableView target:self action:@selector(lastStoryAction:)];
    }
    return _headerLoadView;
}

#pragma mark - 加载下一篇
- (DetailFooterView *)footerLoadView{
    if (_footerLoadView == nil) {
        _footerLoadView = [DetailFooterView attachObserveToScrollView:self.tableView target:self action:@selector(nextStoryAction:)];
    }
    return _footerLoadView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
