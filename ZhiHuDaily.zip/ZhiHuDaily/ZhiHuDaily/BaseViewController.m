//
//  ViewController.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/4.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    //[SVProgressHUD dismiss];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)backAction{
    [SVProgressHUD dismiss];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)HUDShow{
    [SVProgressHUD show];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
}
-(void)HUDShow:(NSString*)text{
    [SVProgressHUD showWithStatus:text];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
}
-(void)HUDShow:(NSString*)text delay:(float)second{
    [SVProgressHUD showWithStatus:text];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, second*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_main_queue(), ^{
        [self hudHidden];
    });
}
-(void)HUDdelayDo
{
    
}
-(void)HUDShow:(NSString*)text delay:(float)second dothing:(BOOL)bDo{
    [SVProgressHUD showWithStatus:text];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, second*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_main_queue(), ^{
        [self HUDdelayDo];
        [self hudHidden];
    });
}
- (void)hudHidden{
    [SVProgressHUD dismiss];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
