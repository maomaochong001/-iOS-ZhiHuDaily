//
//  HomeViewController.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/4.
//  Copyright © 2016年 zemengli. All rights reserved.
//
#import "AppDelegate.h"
#import "HomeViewController.h"
#import "NewsContentViewController.h"
#import "ThemeItemContentVC.h"

#import "BannerView.h"
#import "SectionTitleView.h"
#import "HomeViewCell.h"
#import "ThemeItemCell.h"
#import "ALDBlurImageProcessor.h"
#import "NTRMath.h"
#import "CircleRefreshView.h"

#import "HomeModel.h"
#import "ThemeListModel.h"


#define kRowHeight 88.f
#define kSectionHeaderHeight 36.f
static NSString *CellIdentifier = @"HomeViewCell";
static NSString * const SectionHeaderId = @"header";
@interface HomeViewController ()<UITableViewDataSource,UITableViewDelegate,BannerViewDelegate,NewsContentVCDelegate,ALDBlurImageProcessorDelegate>
@property(nonatomic,strong)UIView                   * navBarBackgroundView;
@property(nonatomic,strong)UILabel                  * tittleLab;
@property(nonatomic,strong)UIButton                 * menuButton;
@property(nonatomic,strong)BannerView               * bannerView;
@property(nonatomic,strong)UITableView              * tableView;
@property(nonatomic,strong)CircleRefreshView        * homeRefreshView;

@property(nonatomic,strong)NSMutableArray           * homeDataArray;
@property(nonatomic,strong)NSMutableArray           * top_storyArray;
@property(nonatomic,strong)NSString                 * currentLoadDayStr;//已加载最靠前那一天的日期字符串

//主题列表View
@property(nonatomic,strong)UIView                   * themesBackGroundView;
@property(nonatomic,strong)UIView                   * headerView;
@property(nonatomic,strong)UIImageView              * imageView;
@property(nonatomic,strong)UILabel                  * themeTittleLab;
@property(nonatomic,strong)UIButton                 * backButton;
@property(nonatomic,strong)UITableView              * themesTableView;
@property(nonatomic,strong)UIView                   * themesTableHeaderView;
@property(nonatomic,strong)ALDBlurImageProcessor    * blurImageProcessor;
@property(nonatomic,assign)BOOL                     ShowThemesView;
@property(nonatomic,copy)CircleRefreshView        * themeRefreshView;

@property(nonatomic,assign)NSInteger                themeID;
@property(nonatomic,strong)ThemeListModel           * themeListModel;
@property(nonatomic,strong)NSMutableArray           * themeListArray;


@end

@implementation HomeViewController

- (NSMutableArray *)homeDataArray{
    if (!_homeDataArray) {
        _homeDataArray = [[NSMutableArray alloc]init];
    }
    return _homeDataArray;
}
- (NSMutableArray *)themeListArray{
    if (!_themeListArray) {
        _themeListArray = [[NSMutableArray alloc]init];
    }
    return _themeListArray;
}

#pragma mark - 主题页刷新圆圈
- (CircleRefreshView *)themeRefreshView{
    if (!_themeRefreshView) {
        _themeRefreshView = [CircleRefreshView attachObserveToScrollView:self.themesTableView
                                                                  target:self
                                                                  action:@selector(getThemeData)];
        _themeRefreshView.frame = CGRectMake(0, 0, 22, 22);
        _themeRefreshView.centerY = self.themeTittleLab.centerY;
        _themeRefreshView.right = self.themeTittleLab.left;
    }
    return _themeRefreshView;
}

- (void)initThemesView{
    _themesBackGroundView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    _themesBackGroundView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_themesBackGroundView];
    _headerView = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, -50, kScreenWidth, 110)];
        view.clipsToBounds = YES;
        [_themesBackGroundView addSubview:view];
        view;
    });
    
    _imageView = ({
        UIImageView * imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 160)];
        imgView.contentMode = UIViewContentModeScaleAspectFill;
        [_headerView addSubview:imgView];
        imgView;
    });
    [_imageView sd_setImageWithURL:nil placeholderImage:[UIImage imageNamed:@"Field_Mask_Bg"]];
    //标题
    _themeTittleLab = ({
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 50, 120, 25)];
        label.numberOfLines = 1;
        label.font = [UIFont boldSystemFontOfSize:19];
        label.textColor = [UIColor whiteColor];
        label.textAlignment = NSTextAlignmentCenter;
        [_themesBackGroundView addSubview:label];
        [label setCenterX:_headerView.width/2];
        [label setCenterY:40];
        label;
    });
    
    //菜单按钮，显示左边菜单
    _backButton = ({
        UIButton * button = [UIButton buttonWithType:0];
        [button setFrame:CGRectMake(0, 0, 44, 44)];
        [button setImage:[UIImage imageNamed:@"Back_White"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(showLeftMenu) forControlEvents:UIControlEventTouchUpInside];
        [_themesBackGroundView addSubview:button];
        [button setCenterY:40];
        button;
    });
    
    _themesTableView = [[UITableView alloc] initWithFrame:CGRectMake(0.f, _headerView.bottom, kScreenWidth, kScreenHeight-60)];
    _themesTableView.delegate = self;
    _themesTableView.dataSource = self;
    _themesTableView.rowHeight = kRowHeight;
    [_themesBackGroundView addSubview:_themesTableView];
    _themesTableHeaderView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 44)];
    _themesTableHeaderView.backgroundColor = [UIColor whiteColor];
    _themesTableView.tableHeaderView = _themesTableHeaderView;
    _themesTableView.backgroundColor = [UIColor clearColor];
    //上拉加载更多
    MJRefreshAutoNormalFooter *footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    footer.refreshingTitleHidden = NO;
    self.themesTableView.mj_footer = footer;
    
    [_themesBackGroundView addSubview:self.themeRefreshView];
}

- (void)setThemeData{
    [self.themesTableView reloadData];
    _themeTittleLab.text = self.themeListModel.name;
    [_imageView sd_setImageWithURL:[NSURL URLWithString:self.themeListModel.image] placeholderImage:[UIImage imageNamed:@"Field_Mask_Bg"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        //先设置透明度为最模糊状态
        _blurImageProcessor = [[ALDBlurImageProcessor alloc] initWithImage: _imageView.image];
        _blurImageProcessor.delegate = self;
        
        [_blurImageProcessor asyncBlurWithRadius: lerp( 1, 5, 5 )
                                      iterations: lerp( 1, 0, 10 )
                          cancelingLastOperation: NO];
    }];
    //添加主编
    //先删除
    for (UIView * view in _themesTableHeaderView.subviews) {
        [view removeFromSuperview];
    }
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 40, 25)];
    label.numberOfLines = 1;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor darkGrayColor];
    label.textAlignment = NSTextAlignmentLeft;
    [_themesTableHeaderView addSubview:label];
    [label setCenterY:_themesTableHeaderView.height/2];
    [label setLeft:10];
    label.text =@"主编";
    for (int i = 0; i<self.themeListModel.editors.count; i++) {
        EditorInfo * editorInfo = [self.themeListModel.editors objectAtIndex:i];
        UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(60+i*(20+10), 0, 20, 20)];
        [imageView setCenterY:_themesTableHeaderView.height/2];
        [imageView sd_setImageWithURL:[NSURL URLWithString:editorInfo.avatar] placeholderImage:[UIImage imageNamed:@"Comment_Avatar"]];
        [_themesTableHeaderView addSubview:imageView];
        UIImageView * maskView = [[UIImageView alloc]initWithFrame:CGRectMake(60+i*(20+10), 0, 20, 20)];
        [maskView setCenterY:_themesTableHeaderView.height/2];
        [maskView setImage:[UIImage imageNamed:@"Comment_Avatar_Mask"]];
        [_themesTableHeaderView addSubview:maskView];
    }
    UIImageView * lineView = [[UIImageView alloc]initWithFrame:CGRectMake(0, _themesTableHeaderView.height-0.5, kScreenWidth, 0.5)];
    lineView.backgroundColor = [UIColor colorWithRed:0.933 green:0.933 blue:0.933 alpha:1.00];
    [_themesTableHeaderView addSubview:lineView];
    
    _themeTittleLab.hidden = NO;
    _backButton.hidden = NO;
    [UIView animateWithDuration:0.3 animations:^(void){
        _themesTableView.alpha = 1;
        
    } completion:^(BOOL finised){
        
    }];
}

#pragma mark - 左侧菜单栏点击
- (void)HomeVCPushToThemesVC:(NSNotification *)noti{
    if ([noti.userInfo[@"selectTheme"] integerValue] == 0) {
        NSLog(@"显示首页");
        
        [self showMainView];
        
        if (!_themesBackGroundView) {
            return;
        }
        _ShowThemesView = NO;
        
        //当前显示的是主题页，就先渐渐消失
        _themeTittleLab.hidden = YES;
        _backButton.hidden = YES;
        [UIView animateWithDuration:0.8 animations:^(void){
            _themesBackGroundView.alpha = 0;
        } completion:^(BOOL finised){
            
        }];
        
    }else{
        NSLog(@"显示主题内容页");
        _ShowThemesView = YES;
        //如果没有创建过界面，先创建界面
        if (!_themesBackGroundView)
        {
            [self initThemesView];
        }else{
            _themesBackGroundView.alpha = 1;
        }
        
        //如果要显示的主题是当前已经显示的，就不用管
        if (self.themeID == [noti.userInfo[@"selectTheme"] integerValue]) {
            
            _themesBackGroundView.alpha = 1;
            _themeTittleLab.hidden = NO;
            _backButton.hidden = NO;
            return;
        }
        
        [UIView animateWithDuration:0.8 animations:^(void){
            _themesTableView.alpha = 0.3;
        } completion:^(BOOL finised){
            
        }];
        
        self.themeID = [noti.userInfo[@"selectTheme"] integerValue];
        [self getThemeData];
    }
}

- (void)getThemeData{
    
    [HttpOperation getRequestWithURL:[NSString stringWithFormat:@"theme/%d",self.themeID] parameters:nil className:@"ThemeListModel" success:^(id responseObject) {
        self.themeListModel = (ThemeListModel *)responseObject;
        if ([_themeListArray count]>0) {
            [_themeListArray removeAllObjects];
        }
        _themeListArray = self.themeListModel.stories;
        //存数据库
        [self saveToDataBase:self.themeListModel.stories];
        [_themeRefreshView endRefreshing];
        [self setThemeData];
    } failure:nil];
    
}

- (void)getLatestData{
    
    [HttpOperation getRequestWithURL:@"news/latest" parameters:nil className:@"HomeModel" success:^(id responseObject) {
        HomeModel * homeModel = (HomeModel *)responseObject;
        self.currentLoadDayStr = homeModel.date;
        NSLog(@"%@",homeModel.date);
        if (self.homeDataArray.count > 0) {
            [self.homeDataArray removeAllObjects];
        }
        //存数据库
        [self saveToDataBase:homeModel.stories];
        
        
        
        [self.homeDataArray addObject:homeModel];
        [homeModel.top_stories addObject:[homeModel.top_stories objectAtIndex:0]];
        [homeModel.top_stories insertObject:[homeModel.top_stories objectAtIndex:homeModel.top_stories.count-2] atIndex:0];
        self.top_storyArray = homeModel.top_stories ;
        [_bannerView setTopStories:homeModel.top_stories];
        [self.tableView reloadData];
        // 拿到当前的上拉刷新控件，结束刷新状态
        [_homeRefreshView endRefreshing];
        
        [self loadMoreData];
    } failure:nil];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(HomeVCPushToThemesVC:) name:@"PushThemesVC" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ThemeItemVCBackToHomeVCAction:) name:@"ThemeItemVCBackToHomeVC" object:nil];
    [self initSubViews];
    
    [self getLatestData];
    NSLog(@"首页");

}

- (void)initSubViews{
    
    //tableView
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.f, 20.f, kScreenWidth, kScreenHeight-20.f)];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = kRowHeight;
    [self.view addSubview:_tableView];
    
    [self.tableView registerClass:[SectionTitleView class] forHeaderFooterViewReuseIdentifier:SectionHeaderId];
    UIView * view = [[UIView alloc] initWithFrame:CGRectMake(0.f, 0.f, kScreenWidth, 200.f)];
    self.tableView.tableHeaderView = view;
    //添加顶部Banner
    BannerView * banner = [[BannerView alloc]initWithFrame:CGRectMake(0, -40, kScreenWidth, 260)];
    banner.delegate = self;
    _bannerView = banner;
    
    [self.view addSubview:banner];
    [_bannerView setClipsToBounds:YES];
    
    //添加上拉刷新
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadMoreData方法）
    MJRefreshAutoNormalFooter *footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    // 当上拉刷新控件出现50%时（出现一半），就会自动刷新。这个值默认是1.0（也就是上拉刷新100%出现时，才会自动刷新）
    //   footer.triggerAutomaticallyRefreshPercent = 0.5;
    // 不隐藏刷新状态的文字
    footer.refreshingTitleHidden = NO;
    // 设置footer
    self.tableView.mj_footer = footer;
    
    //顶部导航栏
    _navBarBackgroundView = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 56)];
        [view setBackgroundColor:[UIColor clearColor]];
        [self.view addSubview:view];
        
        view;
    });
    //标题
    _tittleLab = ({
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 90, 25)];
        label.attributedText = [[NSAttributedString alloc] initWithString:@"今日热闻" attributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:18] ,NSForegroundColorAttributeName:[UIColor whiteColor]}];
        label.textAlignment = NSTextAlignmentCenter;
        [label sizeToFit];
        [self.view addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker * make) {
            make.centerY.equalTo(self.view.mas_top).offset(38);
            make.centerX.equalTo(self.view.mas_centerX);
        }];
        label;
    });
    //菜单按钮，显示左边菜单
    _menuButton = ({
        UIButton * button = [UIButton buttonWithType:0];
        [button setFrame:CGRectMake(16, 28, 22, 22)];
        [button setImage:[UIImage imageNamed:@"Home_Icon"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(showLeftMenu) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
        button;
    });
    
    //添加下拉刷新
    [self.view addSubview:self.homeRefreshView];
}

#pragma mark - 首页刷新圆圈
- (CircleRefreshView *)homeRefreshView{
    if (!_homeRefreshView) {
        _homeRefreshView = [CircleRefreshView attachObserveToScrollView:self.tableView
                                                                 target:self
                                                                 action:@selector(getLatestData)];
        _homeRefreshView.frame = CGRectMake(kScreenWidth/2-45-22, 28, 22, 22);
        
    }
    return _homeRefreshView;
}


- (void)showLeftMenu{
    
    AppDelegate * app = kAppdelegate;
    [app.mainVC showLeftMenuView];
    
}
- (void)showMainView{
    
    AppDelegate * app = kAppdelegate;
    [app.mainVC showMainView];
    
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat offSetY = scrollView.contentOffset.y;
    //NSLog(@"offSetY:   %f",offSetY);
    
    if ([scrollView isEqual:_tableView]) {
        
        if (-offSetY <=80&&-offSetY>=0) {
            _bannerView.frame = CGRectMake(0, -40+(-offSetY/2), kScreenWidth, 260+(-offSetY/2));
            [_bannerView updateSubViewsOriginY:-offSetY];
        }
        else if (-offSetY>80){
            //限制最大偏移量
            _bannerView.frame = CGRectMake(0, 0, kScreenWidth,320);
            _tableView.contentOffset = CGPointMake(0, -80);
        }
        
        if (offSetY <= 0) {
            _navBarBackgroundView.backgroundColor = [UIColor colorWithRed:0.231 green:0.549 blue:0.835 alpha:0.00];
        }
        else if(offSetY <= 300){
            _navBarBackgroundView.backgroundColor = [UIColor colorWithRed:0.231 green:0.549 blue:0.835 alpha:offSetY/165];
            _bannerView.frame = CGRectMake(0, -40-offSetY, kScreenWidth, 260);
            
        }
        
    }
    else if ([scrollView isEqual:_themesTableView]){
        //向下拉
        if (-offSetY <=100&&-offSetY>=0) {
            _headerView.frame = CGRectMake(0, -50+(-offSetY/2), kScreenWidth, 110+(-offSetY/2));
            //透明度
            [_blurImageProcessor asyncBlurWithRadius: lerp( (100-(-offSetY))/100, 5, 5 )
                                          iterations: lerp(  (100-(-offSetY))/100, 0, 10 )
                              cancelingLastOperation: NO];
        }
        else if (-offSetY>100){
            //限制最大偏移量
            _themesTableView.contentOffset = CGPointMake(0, -100);
            _headerView.frame = CGRectMake(0, 0, kScreenWidth, 160);
        }
        //向上拉
        else if(offSetY<=160){
            _headerView.frame = CGRectMake(0, -50, kScreenWidth, 110);
            
        }
        
        
    }
}
#pragma mark - ALDBlurImageProcessorDelegate

-( void )onALDBlurImageProcessor:( ALDBlurImageProcessor * )blurImageProcessor newBlurrredImage:( UIImage * )image
{
    _imageView.image = image;
}

-( void )onALDBlurImageProcessor:( ALDBlurImageProcessor * )blurImageProcessor blurProcessingErrorCode:( NSNumber * )errorCode
{
    NSLog(@"模糊图片出错");
    //[self showBlurImageProcessorErrorCode: errorCode];
}
#pragma mark - BannerViewDelegate 首页顶部banner点击
- (void)didSelectItemWithTag:(NSInteger)tag{
    
    StoryInfo * storyInfo = [self.top_storyArray objectAtIndex:tag-100];
    
    HomeModel * homemodel = [self.homeDataArray objectAtIndex:0];
    NSMutableArray * dataArr = homemodel.stories;
    if (self.homeDataArray.count > 1) {
        HomeModel * homemodel2 = [self.homeDataArray objectAtIndex:1];
        [dataArr addObjectsFromArray:homemodel2.stories];
    }
    
    for (int i=0;i<dataArr.count;i++) {
        
        StoryInfo * storyInfo2 = [dataArr objectAtIndex:i];
        
        if (storyInfo2.id == storyInfo.id) {
            NewsContentViewController * newsContentVC = [[NewsContentViewController alloc]init];
            newsContentVC.stroryInfo = storyInfo;
            newsContentVC.dataArr = self.homeDataArray;
            newsContentVC.sectionIndex = 0;
            newsContentVC.rowIndex = i;
            newsContentVC.delegate = self;
            AppDelegate * app = kAppdelegate;
            [app.mainVC.navigationController pushViewController:newsContentVC animated:YES];
            return;
        }
    }
    
}

#pragma mark - NewsContentVCDelegate 返回时候要把详情页请求下来的最新数据带过来，刷新
- (void)backWithDataArr:(NSMutableArray *)dataArr{
    self.homeDataArray = dataArr;
    [self.tableView reloadData];
}
#pragma mark - 如果是主题详情页返回到首页主题列表页，刷新主题列表
- (void)ThemeItemVCBackToHomeVCAction:(NSNotification *)noti
{
    [self.themesTableView reloadData];
}
#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (_ShowThemesView) {
        return 1;
    }
    else{
        return self.homeDataArray.count;
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (_ShowThemesView)
    {
        
        return _themeListArray.count;
        
    }
    else{
        HomeModel * homemodel = [self.homeDataArray objectAtIndex:section];
        return homemodel.stories.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_ShowThemesView)
    {
        static NSString *identifier = @"ThemeItemCell";
        ThemeItemCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil) {
            cell = [[ThemeItemCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] ;
        }
        
        StoryInfo * themeItem = [_themeListArray objectAtIndex:indexPath.row];
        [cell settingData:themeItem];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
        
    }
    else{
        static NSString *identifier = @"HomeViewCell";
        HomeViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil) {
            cell = [[HomeViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] ;
        }
        
        HomeModel * homemodel = [self.homeDataArray objectAtIndex:indexPath.section];
        StoryInfo * stroryInfo = [homemodel.stories objectAtIndex:indexPath.row];
        
        [cell settingData:stroryInfo];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
    
}
#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_ShowThemesView && [tableView isEqual:_themesTableView])
    {
        StoryInfo * themeItem                   = [_themeListArray objectAtIndex:indexPath.row];
        ThemeItemContentVC * themeItemContent   = [[ThemeItemContentVC alloc]init];
        themeItemContent.themeItem              = themeItem;
        themeItemContent.dataArr                = _themeListArray;
        AppDelegate * app                       = kAppdelegate;
        [app.mainVC.navigationController pushViewController:themeItemContent animated:YES];
    }
    else
    {
        
        NewsContentViewController * newsContentVC = [[NewsContentViewController alloc]init];
        HomeModel * homemodel                     = [self.homeDataArray objectAtIndex:indexPath.section];
        StoryInfo * stroryInfo                    = [homemodel.stories objectAtIndex:indexPath.row];
        newsContentVC.stroryInfo                  = stroryInfo;
        newsContentVC.dataArr                     = self.homeDataArray;
        newsContentVC.sectionIndex                = indexPath.section;
        newsContentVC.rowIndex                    = indexPath.row;
        newsContentVC.delegate                    = self;
        AppDelegate * app                         = kAppdelegate;
        [app.mainVC.navigationController pushViewController:newsContentVC animated:YES];
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return CGFLOAT_MIN;
    }
    return kSectionHeaderHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return nil;
    }
    SectionTitleView * headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:SectionHeaderId];
    HomeModel * homemodel = [self.homeDataArray objectAtIndex:section];
    [headerView setTittleText:[self stringConvertToSectionTitleText:homemodel.date]];
    return headerView;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    if (section == 0) {
        
        [self.navBarBackgroundView setMj_h:56.f];
        _tittleLab.alpha = 1.f;
        
    }
}

- (void)tableView:(UITableView *)tableView didEndDisplayingHeaderView:(UIView *)view forSection:(NSInteger)section {
    if (section == 0) {
        
        [self.navBarBackgroundView setMj_h:20.f];
        _tittleLab.alpha = 0.f;
        
    }
}

#pragma mark 下拉刷新数据
- (void)loadNewData{
    
    [self getLatestData];
    
}
#pragma mark 上拉加载更多数据
- (void)loadMoreData{
    if (_ShowThemesView)
    {
        StoryInfo * themeItem = [_themeListArray lastObject];
        [HttpOperation getRequestWithURL:[NSString stringWithFormat:@"theme/%d/before/%d",self.themeID,themeItem.id] parameters:nil className:@"ThemeListModel" success:^(id responseObject) {
            
            self.themeListModel = (ThemeListModel *)responseObject;
            [self.themeListArray addObjectsFromArray:self.themeListModel.stories];
            //存数据库
            [self saveToDataBase:self.themeListModel.stories];
            
            [self.themesTableView reloadData];
            // 拿到当前的上拉刷新控件，结束刷新状态
            [self.themesTableView.mj_footer endRefreshing];
        } failure:nil];
    }
    else
    {
        [HttpOperation getRequestWithURL:[NSString stringWithFormat:@"news/before/%@",_currentLoadDayStr] parameters:nil className:@"HomeModel" success:^(id responseObject) {
            HomeModel * homeModel = (HomeModel *)responseObject;
            self.currentLoadDayStr = homeModel.date;
            
            [self.homeDataArray addObject:homeModel];
            //存数据库
            [self saveToDataBase:homeModel.stories];
            
            [self.tableView reloadData];
            // 拿到当前的上拉刷新控件，结束刷新状态
            [self.tableView.mj_footer endRefreshing];
        } failure:nil];
    }
    
}

#pragma mark 数据存入数据库
- (void)saveToDataBase:(NSMutableArray *)array{
    for (int i=0; i<array.count; i++) {
        //先查询有没有这条数据
        StoryInfo * sInfo = [array objectAtIndex:i];
            StoryInfo * sInfo2 = [StoryInfo findFirstByCriteria:[NSString stringWithFormat:@"WHERE id=%d",sInfo.id]];
            //没有的话保存进数据库
            if (!sInfo2) {
                [sInfo save];
            }
    }
}

- (NSString*)stringConvertToSectionTitleText:(NSString*)str {
    
    NSDateFormatter *formatter = [NSDateFormatter sharedInstance];
    [formatter setDateFormat:@"yyyyMMdd"];
    NSDate *date1 = [formatter dateFromString:str];
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"zh-CH"];
    [formatter setDateFormat:@"MM月dd日 EEEE"];
    NSString *sectionTitleText = [formatter stringFromDate:date1];
    
    return sectionTitleText;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
