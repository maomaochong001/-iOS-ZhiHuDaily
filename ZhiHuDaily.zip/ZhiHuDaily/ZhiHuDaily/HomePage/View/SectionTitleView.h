//
//  SectionTitleView.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/14.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SectionTitleView : UITableViewHeaderFooterView

- (void)setTittleText:(NSString *)text;

@end
