//
//  HomeViewCell.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/15.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
@interface HomeViewCell : UITableViewCell
- (void)settingData:(StoryInfo *)storyInfo;
@end
