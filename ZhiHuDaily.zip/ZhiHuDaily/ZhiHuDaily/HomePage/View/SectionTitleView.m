//
//  SectionTitleView.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/14.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "SectionTitleView.h"

@interface SectionTitleView()
/** 内部的label */
@property (nonatomic, strong) UILabel *label;
@end

@implementation SectionTitleView
- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = kNavigationBarColor;
        // label
        UILabel *label = [[UILabel alloc] init];
        label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont boldSystemFontOfSize:18];
        [self.contentView addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker * make) {
            make.centerX.equalTo(self.mas_centerX);
            make.centerY.equalTo(self.mas_centerY);
        }];
        self.label = label;
    }
    return self;
}

- (void)setTittleText:(NSString *)text
{
    self.label.text = text;
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}*/

@end
