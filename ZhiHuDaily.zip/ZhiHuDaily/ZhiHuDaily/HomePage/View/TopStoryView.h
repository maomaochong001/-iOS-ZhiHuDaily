//
//  TopStoryView.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/8.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopStoryView : UIView

@property (strong,nonatomic) UIImageView *imageView;
@property (strong,nonatomic) UILabel *label;

@end
