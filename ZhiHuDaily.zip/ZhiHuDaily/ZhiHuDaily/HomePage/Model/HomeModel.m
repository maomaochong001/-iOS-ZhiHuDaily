//
//  HomeModel.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/7.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "HomeModel.h"
#import "NSDictionary+JSON.h"

@implementation StoryInfo
@synthesize title;
@synthesize ga_prefix;
@synthesize images;
@synthesize multipic;
@synthesize type;
@synthesize id;
@synthesize readAlready;
@synthesize favourite;


@end

@implementation TopStoryInfo
@synthesize title;
@synthesize ga_prefix;
@synthesize image;
@synthesize type;
@synthesize id;
@end


@implementation HomeModel
@synthesize date;
@synthesize stories;
@synthesize top_stories;
- (NSMutableArray *)stories {
    for (int i = 0; i < stories.count; i++) {
        if([[stories objectAtIndex:i] class] != [StoryInfo class]) {
            NSDictionary * _dic = (NSDictionary *)[stories objectAtIndex:i];
            [stories replaceObjectAtIndex:i withObject:[_dic dictionaryTo:NSClassFromString(@"StoryInfo")]];
        }
    }
    return stories;
}

- (NSMutableArray *)top_stories {
    for (int i = 0; i < top_stories.count; i++) {
        if([[top_stories objectAtIndex:i] class] != [TopStoryInfo class]) {
            NSDictionary * _dic = (NSDictionary *)[top_stories objectAtIndex:i];
            [top_stories replaceObjectAtIndex:i withObject:[_dic dictionaryTo:NSClassFromString(@"TopStoryInfo")]];
        }
    }
    return top_stories;
}


@end
