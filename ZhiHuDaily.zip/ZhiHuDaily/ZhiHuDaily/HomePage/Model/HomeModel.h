//
//  HomeModel.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/7.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JKDBModel.h"
@interface StoryInfo : JKDBModel
{
    NSString        * title;
    NSString        * ga_prefix;
    NSMutableArray  * images;
    BOOL            multipic;
    NSInteger       type;
    NSInteger       id;
    NSInteger       readAlready;
    NSInteger       favourite;
}

@property(nonatomic,copy) NSString        * title;
@property(nonatomic,copy) NSString        * ga_prefix;
@property(nonatomic,copy) NSMutableArray  * images;
@property(nonatomic, assign) BOOL           multipic;
@property(nonatomic, assign) NSInteger      type;
@property(nonatomic, assign) NSInteger      id;
@property(nonatomic, assign) NSInteger      readAlready;
@property(nonatomic, assign) NSInteger      favourite;
@end

@interface TopStoryInfo : NSObject
{
    NSString        * title;
    NSString        * ga_prefix;
    NSString        * image;
    NSInteger         type;
    NSInteger         id;
}

@property(nonatomic,strong) NSString * title;
@property(nonatomic,strong) NSString * ga_prefix;
@property(nonatomic,strong) NSString * image;
@property(assign,readonly) NSInteger         type;
@property(assign,readonly) NSInteger         id;
@end

@interface HomeModel : NSObject
{
    NSString        * date;
    NSMutableArray  * stories;
    NSMutableArray  * top_stories;
}

@property(nonatomic,strong) NSString *date;
@property(nonatomic,strong) NSMutableArray *stories;
@property(nonatomic,strong) NSMutableArray *top_stories;
@end
