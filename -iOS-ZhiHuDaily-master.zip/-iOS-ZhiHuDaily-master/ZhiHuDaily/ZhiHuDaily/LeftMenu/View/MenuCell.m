//
//  MenuCell.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/2/25.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "MenuCell.h"
#define LeftOffset              15
#define cellShowWidth           kScreenWidth*0.7*0.8//cell显示区域
@interface MenuCell()

@property (nonatomic,strong) UIImageView    * lineImg1;
@property (nonatomic,assign) BOOL           selfIsFirstRow;
@end

@implementation MenuCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor colorWithRed:0.141 green:0.165 blue:0.188 alpha:1.00];
        _imgViewRight = ({
            UIImageView  * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(cellShowWidth-15, 16, 15, 18)];
            [self.contentView addSubview:imageView];
            imageView;
        });
        // label
        _label = ({
            UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(LeftOffset, 13, cellShowWidth-30-LeftOffset, 24)];
            label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            label.textColor = [UIColor colorWithRed:0.584 green:0.600 blue:0.616 alpha:1.00];
            label.font = [UIFont systemFontOfSize:16];
            label.numberOfLines = 1;
            [self.contentView addSubview:label];
            label;
        });
        _imgViewLeft = ({
            UIImageView  * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(LeftOffset, 15, 20, 20)];
            [self.contentView addSubview:imageView];
            imageView;
        });
        _lineImg1 = ({
            UIImageView  * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 49, self.width, 1)];
            [imageView setBackgroundColor:[UIColor colorWithRed:0.125 green:0.149 blue:0.173 alpha:1.00]];
            [self.contentView addSubview:imageView];
            imageView;
        });
    }
    return self;
}
- (void)settingData:(ThemeItemDetailModel *)themeItemDetail isFirstRow:(BOOL)FirstRow{
    _selfIsFirstRow = FirstRow;
    
    if (FirstRow) {
        _label.text = @"首页";
    }
    else {
        _label.text = themeItemDetail.name;
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.selfIsFirstRow) {
        _imgViewLeft.hidden = NO;
        _lineImg1.hidden = NO;
        [_imgViewRight setFrame:CGRectMake(cellShowWidth-15, 16, 15, 18)];
        
        [_label setFrame:CGRectMake(_imgViewLeft.right+LeftOffset, 13, kScreenWidth*0.7*0.8-_imgViewLeft.width-_imgViewRight.width-LeftOffset*2, 24)];
    }
    else {
        _imgViewLeft.hidden = YES;
        _lineImg1.hidden = YES;
        [_imgViewRight setFrame:CGRectMake(cellShowWidth-15, 16, 15, 18)];
        [_label setFrame:CGRectMake(LeftOffset, 13, cellShowWidth-_imgViewRight.width-LeftOffset, 24)];
    }
}



@end
