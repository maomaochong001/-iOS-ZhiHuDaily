//
//  LeftMenuViewController.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/5.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "AppDelegate.h"
#import "LeftMenuViewController.h"

#import "MenuCell.h"

#import "ThemeItemModel.h"

#define LeftOffset              15
#define CellRowHeight           50
@interface LeftMenuViewController ()<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong)UITableView          * tableView;

@property(nonatomic,strong)NSMutableArray       * dataArray;
@property(nonatomic,assign)NSInteger            selectRow;

@end

@implementation LeftMenuViewController

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.selectRow = 100;
    [self getThemeList];
    [self initUI];
    NSLog(@"左侧主题菜单栏");
}

- (void)getThemeList{
    
    [HttpOperation getRequestWithURL:@"themes" parameters:nil className:@"ThemeItemModel" success:^(id responseObject) {
        ThemeItemModel * themeItemModel = (ThemeItemModel *)responseObject;
        self.dataArray = themeItemModel.others;
        
        [self.tableView reloadData];
    } failure:nil];
     
}

- (void)goToMyFavouriteViewController:(id)sender{
    
    AppDelegate * app = kAppdelegate;
    [app.mainVC showMainView];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"PushFavouriteVC" object:nil userInfo:nil];
}

- (void)initUI{
    
    UIView * backView = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth*0.7, kScreenHeight)];
        view.backgroundColor = [UIColor colorWithRed:0.141 green:0.165 blue:0.188 alpha:1.00];
        [self.view addSubview:view];
        view;
    });
    
    UIView * top1View = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 20, kScreenWidth*0.7*0.8, 55)];
        [backView addSubview:view];
        
        UIImageView * imgView = [[UIImageView alloc]initWithFrame:CGRectMake(LeftOffset, 10, 35, 35)];
        [imgView setImage:[UIImage imageNamed:@"Dark_Menu_Avatar"]];
        [view addSubview:imgView];
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(LeftOffset+35+LeftOffset, 10, 70, 35)];
        label.text = @"请登录";
        label.font = [UIFont systemFontOfSize:16];
        label.textColor = [UIColor colorWithRed:0.584 green:0.600 blue:0.616 alpha:1.00];
        [view addSubview:label];
        
        view;
    });
    
    UIView * top2View = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, top1View.width, CellRowHeight)];
        [backView addSubview:view];
        
        UIImageView * imgView = [[UIImageView alloc]initWithFrame:CGRectMake(LeftOffset, 5, 20, 20)];
        [imgView setImage:[UIImage imageNamed:@"Dark_Menu_Icon_Collect"]];
        [view addSubview:imgView];
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(LeftOffset, 5+20, 40, 20)];
        label.text = @"收藏";
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:12];
        label.textColor = [UIColor colorWithRed:0.584 green:0.600 blue:0.616 alpha:1.00];
        [view addSubview:label];
        [label setCenterX:imgView.centerX];
        
        UIImageView * imgView2 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 5, 20, 20)];
        [imgView2 setImage:[UIImage imageNamed:@"Dark_Menu_Icon_Message"]];
        [view addSubview:imgView2];
        [imgView2 setCenterX:view.centerX];
        UILabel * label2 = [[UILabel alloc]initWithFrame:CGRectMake(0, 5+20, 40, 20)];
        label2.text = @"消息";
        label2.textAlignment = NSTextAlignmentCenter;
        label2.font = [UIFont systemFontOfSize:12];
        label2.textColor = [UIColor colorWithRed:0.584 green:0.600 blue:0.616 alpha:1.00];
        [view addSubview:label2];
        [label2 setCenterX:imgView2.centerX];
        
        UIImageView * imgView3 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 5, 20, 20)];
        [imgView3 setImage:[UIImage imageNamed:@"Dark_Menu_Icon_Setting"]];
        [view addSubview:imgView3];
        [imgView3 setCenterX:view.width-LeftOffset-10];
        UILabel * label3 = [[UILabel alloc]initWithFrame:CGRectMake(0, 5+20, 40, 20)];
        label3.text = @"设置";
        label3.textAlignment = NSTextAlignmentCenter;
        label3.font = [UIFont systemFontOfSize:12];
        label3.textColor = [UIColor colorWithRed:0.584 green:0.600 blue:0.616 alpha:1.00];
        [view addSubview:label3];
        [label3 setCenterX:imgView3.centerX];
        
        UIImageView  * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, view.bottom-1, backView.width, 1)];
        [lineImageView setBackgroundColor:[UIColor colorWithRed:0.125 green:0.149 blue:0.173 alpha:1.00]];
        [view addSubview:lineImageView];
        
        
        view;
    });
    [top2View setTop:top1View.bottom];
    
    
    ({
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(0, 5, 20+LeftOffset*2, 40)];
        [button addTarget:self action:@selector(goToMyFavouriteViewController:) forControlEvents:UIControlEventTouchUpInside];
        [top2View addSubview:button];
    });
    
    UIView * bottomView = ({
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, backView.height-55, kScreenWidth*0.7*0.8, 55)];
        [backView addSubview:view];
        
        UIImageView * imgView = [[UIImageView alloc]initWithFrame:CGRectMake(LeftOffset, 15, 25, 25)];
        [imgView setImage:[UIImage imageNamed:@"Menu_Download"]];
        [view addSubview:imgView];
        [imgView setCenterY:view.height/2];
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 70, 35)];
        label.text = @"离线";
        label.font = [UIFont systemFontOfSize:15];
        label.textColor = [UIColor colorWithRed:0.584 green:0.600 blue:0.616 alpha:1.00];
        [view addSubview:label];
        [label setLeft:imgView.right+LeftOffset];
        [label setCenterY:imgView.centerY];
        
        UIImageView * imgView2 = [[UIImageView alloc]initWithFrame:CGRectMake(view.width/2+LeftOffset, 10, 25, 25)];
        [imgView2 setImage:[UIImage imageNamed:@"Menu_Dark"]];
        [view addSubview:imgView2];
        [imgView2 setCenterY:view.height/2];
        UILabel * label2 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 70, 35)];
        label2.text = @"夜间";
        label2.font = [UIFont systemFontOfSize:15];
        label2.textColor = [UIColor colorWithRed:0.584 green:0.600 blue:0.616 alpha:1.00];
        [view addSubview:label2];
        [label2 setLeft:imgView2.right+LeftOffset];
        [label2 setCenterY:imgView2.centerY];
        
        view;
    });
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.f, top2View.bottom, backView.width, backView.height-top1View.height-top2View.height-bottomView.height-20)];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = CellRowHeight;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.showsVerticalScrollIndicator=NO;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [backView addSubview:_tableView];
    
    //菜单底部透明度渐变效果
    UIImageView * translucentView = [[UIImageView alloc]initWithFrame:CGRectMake(0, _tableView.bottom-CellRowHeight, _tableView.width, CellRowHeight)];
    [translucentView setBackgroundColor:[UIColor colorWithRed:0.141 green:0.165 blue:0.188 alpha:1]];
        CAGradientLayer *_gradLayer = [CAGradientLayer layer];
        NSArray *colors = [NSArray arrayWithObjects:
                           (id)[[UIColor colorWithWhite:0 alpha:1] CGColor],
                           (id)[[UIColor colorWithWhite:0 alpha:0.35] CGColor],
                           (id)[[UIColor colorWithWhite:0 alpha:0] CGColor],
                           nil];
        [_gradLayer setColors:colors];
        //渐变起止点，point表示向量
        [_gradLayer setStartPoint:CGPointMake(0.0f, 1.0f)];
        [_gradLayer setEndPoint:CGPointMake(0.0f, 0.0f)];
        
        [_gradLayer setFrame:translucentView.bounds];
        
        [translucentView.layer setMask:_gradLayer];

    [backView addSubview:translucentView];
}


#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count+1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"MenuCell";
    MenuCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil) {
        cell = [[MenuCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] ;
        cell.backgroundColor = [UIColor colorWithRed:0.141 green:0.165 blue:0.188 alpha:1.00];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.row==0) {
        [cell settingData:nil  isFirstRow:YES];
    }
    else{
        ThemeItemDetailModel * themeItemDetailModel = [self.dataArray objectAtIndex:indexPath.row-1];
        [cell settingData:themeItemDetailModel  isFirstRow:NO];
    }
    
    if (self.selectRow==indexPath.row) {
        [cell.imgViewLeft setImage:[UIImage imageNamed:@"Menu_Icon_Home_Highlight"]];
        cell.imgViewLeft.hidden = NO;
        cell.label.textColor = [UIColor whiteColor];
        cell.label.font = [UIFont boldSystemFontOfSize:16];
        cell.contentView.backgroundColor = [UIColor colorWithRed:0.110 green:0.137 blue:0.161 alpha:1.00];
    }
    else{
        [cell.imgViewLeft setImage:[UIImage imageNamed:@"Menu_Icon_Home"]];
        cell.label.textColor = [UIColor colorWithRed:0.584 green:0.600 blue:0.616 alpha:1.00];
        cell.label.font = [UIFont systemFontOfSize:16];
        cell.contentView.backgroundColor = [UIColor colorWithRed:0.141 green:0.165 blue:0.188 alpha:1.00];
    }
    if (indexPath.row==0) {
        [cell.imgViewRight setImage:[UIImage imageNamed:@"Menu_Enter"]];
    }
    else{
        [cell.imgViewRight setImage:[UIImage imageNamed:@"Menu_Follow"]];
    }
    return cell;
}
#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //点击刷新样式
    self.selectRow = indexPath.row;
    [self.tableView reloadData];
    
//    AppDelegate * app = kAppdelegate;
//    [app.mainVC showMainView];
    NSMutableDictionary * dic = [[NSMutableDictionary alloc]init];
    if (indexPath.row==0) {
        [dic setValue:[NSNumber numberWithInt:0] forKey:@"selectTheme"];
    }else{
        ThemeItemDetailModel * themeItemDetailModel = [self.dataArray objectAtIndex:indexPath.row-1];
        [dic setValue:[NSNumber numberWithInt:themeItemDetailModel.id] forKey:@"selectTheme"];
    }
    [[NSNotificationCenter defaultCenter]postNotificationName:@"PushThemesVC" object:nil userInfo:dic];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
