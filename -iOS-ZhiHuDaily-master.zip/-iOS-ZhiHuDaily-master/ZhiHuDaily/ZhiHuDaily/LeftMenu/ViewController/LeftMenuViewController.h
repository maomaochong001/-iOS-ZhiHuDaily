//
//  LeftMenuViewController.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/5.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface LeftMenuViewController :BaseViewController

@end
