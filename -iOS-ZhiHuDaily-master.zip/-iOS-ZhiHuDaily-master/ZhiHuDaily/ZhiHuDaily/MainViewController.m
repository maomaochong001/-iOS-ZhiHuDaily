//
//  MainViewController.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/4.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "MainViewController.h"
#import "Global.h"


#define RightMoveMaxValue       kScreenWidth*0.7
#define LeftMoveXMaxValue       -kScreenWidth*0.7

@interface MainViewController ()

@property(strong,nonatomic) HomeViewController * homeViewController;
@property(strong,nonatomic) LeftMenuViewController * leftViewController;
@property(strong,nonatomic) UIView * mainView;
@property(strong,nonatomic) UIView * leftMenuView;
@property(assign,nonatomic) CGFloat distance;
@property(strong,nonatomic) UITapGestureRecognizer * tap;

@end

@implementation MainViewController
- (instancetype)initWithLeftMenuViewController:(LeftMenuViewController *)menuVC
                         andHomeViewController:(HomeViewController *)homeVC {
    self = [super init];
    if (self) {
        self.leftViewController = menuVC;
        self.homeViewController = homeVC;
    }
    return self;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    _distance = 0;
    
    self.leftMenuView = _leftViewController.view;
    self.leftMenuView.frame = kScreenBounds;
    self.leftMenuView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, LeftMoveXMaxValue, 0);
    [self.view addSubview:self.leftMenuView];
    self.mainView = _homeViewController.view;
    self.mainView.frame = kScreenBounds;
    [self.view addSubview:self.mainView];
//    CGAffineTransformMakeTranslation : 每次都是以最初位置的中心点为参考
//    
//    CGAffineTransformTranslate 每次都是以传入的transform为参照（既 有叠加效果）
//    
//    CGAffineTransformIdentity  最初位置的中心点
    /**
     *  缩放
     *
     *  @param transform 获取当前的形变 transform
     *  @param sx       水平方向缩放比例
     *  @param sy       垂直方向缩放比例
     *
     *  @return 缩放后结果
     */
    //self.leftMenuView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, 1, 1);
    /**
     *  平移
     *
     *  @param transform 获取当前的形变 transform
     *  @param tx        沿着 x 水平方向的平移
     *  @param ty        沿着 y 垂直方向的平移
     *
     *  @return 返回移动之后的结果
     */
    //self.leftMenuView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity,-kScreenWidth*0.7,0);
    //CGAffineTransformConcat //合并两个Transformation
    //上面两行可以合并为下面
    //self.leftMenuView.transform = CGAffineTransformConcat(CGAffineTransformTranslate(CGAffineTransformIdentity, 1, 1), CGAffineTransformTranslate(CGAffineTransformIdentity,LeftMoveXMaxValue,0));
    //其实不用缩放，可以只平移
    
    UIPanGestureRecognizer * panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
    [self.mainView addGestureRecognizer:panGesture];
    
    _tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(mainViewTap:)];
    
}

- (void)pan:(UIPanGestureRecognizer *)recongizer {
    
    CGFloat moveX = [recongizer translationInView:self.view].x;
    CGFloat trueDistance = _distance + moveX;
    //NSLog(@"%f   %f",moveX,trueDistance);
    if (trueDistance >= 0 && trueDistance <= RightMoveMaxValue) {
        self.mainView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, trueDistance, 0);
        self.leftMenuView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, LeftMoveXMaxValue+trueDistance, 0);
    }
    if (recongizer.state == UIGestureRecognizerStateEnded) {
        if (trueDistance <= RightMoveMaxValue/2) {
            NSLog(@"显示主界面");
            [self showMainView];
        }
        else{
            NSLog(@"显示左菜单");
            [self showLeftMenuView];
        }
    }
}

- (void)showMainView{
    [UIView animateWithDuration:AnimateDuration delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.mainView.transform = CGAffineTransformIdentity;
        self.leftMenuView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, LeftMoveXMaxValue, 0);
    } completion:^(BOOL finished) {
        _distance = 0;
        [self.mainView removeGestureRecognizer:_tap];
    }];
    
   
}

- (void)showLeftMenuView{
    
    [UIView animateWithDuration:AnimateDuration delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.mainView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, RightMoveMaxValue, 0);
        self.leftMenuView.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        _distance = RightMoveMaxValue;
        [self.mainView addGestureRecognizer:_tap];
    }];
    
}

- (void)mainViewTap:(UITapGestureRecognizer *)recongizer {
    [self showMainView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
