//
//  MainViewController.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/4.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuViewController.h"
#import "HomeViewController.h"
@interface MainViewController : UIViewController

- (instancetype)initWithLeftMenuViewController:(LeftMenuViewController *)menuVC
                         andHomeViewController:(HomeViewController *)homeVC;
- (void)showLeftMenuView;
- (void)showMainView;
@end
