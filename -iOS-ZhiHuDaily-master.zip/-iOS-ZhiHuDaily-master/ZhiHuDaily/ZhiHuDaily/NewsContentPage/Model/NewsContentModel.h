//
//  NewsContentModel.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/29.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Theme : NSObject
{
    NSString        * thumbnail;
    NSString        * name;
    NSInteger         id;
}

@property(nonatomic,strong) NSString        * thumbnail;
@property(nonatomic,strong) NSString        * name;
@property(nonatomic,assign) NSInteger         id;
@end


@interface Recommender : NSObject
{
    NSString        * avatar;
}
@property(nonatomic,strong) NSString        * avatar;
@end



@interface NewsContentModel : NSObject
{
    NSString        * body;
    NSString        * image_source;
    NSString        * title;
    NSString        * image;
    NSString        * share_url;
    NSMutableArray  * js;
    NSString        * ga_prefix;
    NSInteger         type;
    NSInteger         id;
    NSMutableArray  * css;
    
    NSMutableArray  * recommenders;
    Theme           * theme;
    
}

@property(nonatomic,strong) NSString        * body;
@property(nonatomic,strong) NSString        * image_source;
@property(nonatomic,strong) NSString        * title;
@property(nonatomic,strong) NSString        * image;
@property(nonatomic,strong) NSString        * share_url;
@property(nonatomic,strong) NSMutableArray  * js;
@property(nonatomic,strong) NSString        * ga_prefix;
@property(nonatomic,assign) NSInteger         type;
@property(nonatomic,assign) NSInteger         id;
@property(nonatomic,strong) NSMutableArray  * css;

@property(nonatomic,strong) NSMutableArray  * recommenders;
@property(nonatomic,strong) Theme           * theme;
@end
