//
//  NSDateFormatter+Extension.h
//  HPYZhiHuDaily
//
//  Created by 洪鹏宇 on 15/11/22.
//  Copyright © 2015年 洪鹏宇. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateFormatter (Extension)

+ (instancetype)sharedInstance;

@end
