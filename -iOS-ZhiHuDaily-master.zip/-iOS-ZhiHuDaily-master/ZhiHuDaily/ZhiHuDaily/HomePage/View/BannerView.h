//
//  BannerView.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/8.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BannerViewDelegate <NSObject>

- (void)didSelectItemWithTag:(NSInteger)tag;

@end


@interface BannerView : UIView

@property(nonatomic,weak) id<BannerViewDelegate> delegate;
- (void)setTopStories:(NSArray *)topStories;
- (void)updateSubViewsOriginY:(CGFloat)value;
@end
