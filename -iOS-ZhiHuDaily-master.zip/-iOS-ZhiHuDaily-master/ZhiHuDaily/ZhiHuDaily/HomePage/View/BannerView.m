//
//  BannerView.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/8.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "BannerView.h"
#import "TopStoryView.h"
#import "HomeModel.h"
@interface BannerView()<UIScrollViewDelegate>

@property(strong,nonatomic)UIScrollView *scrollView;
@property(strong,nonatomic)UIPageControl *pageControl;
@property(strong,nonatomic)NSTimer *timer;

@end
@implementation BannerView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 300)];
        _scrollView.contentSize = CGSizeMake(kScreenWidth*7, 0);
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.delegate = self;
        [self addSubview:_scrollView];
        for (int i = 0; i < 7; i++) {
            TopStoryView * topStoryView = [[TopStoryView alloc]initWithFrame:CGRectMake(kScreenWidth*i, 0, kScreenWidth, 300)];
            [topStoryView setTag:(i+100)];
            [topStoryView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)]];
            [_scrollView addSubview:topStoryView];
            
        }
        _pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(0, 240, kScreenWidth, 20)];
        _pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
        [self addSubview:_pageControl];
    }
    return self;
}

- (void)tap:(UIGestureRecognizer *)recognizer {
    
    if ([self.delegate respondsToSelector:@selector(didSelectItemWithTag:)])
    {
        [self.delegate didSelectItemWithTag:recognizer.view.tag];
    }
    
}

- (void)setTopStories:(NSArray *)topStories {
    //取消定时器
    [_timer invalidate];
    _timer = nil;
    //设置页数
    _pageControl.numberOfPages = topStories.count-2;
    //scrollview当前显示区域顶点相对于frame顶点的偏移量
    _scrollView.contentOffset = CGPointMake(kScreenWidth, 0);
    _pageControl.currentPage = 0;
    for (int i = 0; i < topStories.count; i++) {
        TopStoryView * topStoryView = [_scrollView viewWithTag:(100+i)];
        TopStoryInfo * topStoryInfo = [topStories objectAtIndex:i];
        [topStoryView.imageView sd_setImageWithURL:[NSURL URLWithString:topStoryInfo.image]];
        NSAttributedString * attString = [[NSAttributedString alloc]initWithString:topStoryInfo.title attributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:21],NSForegroundColorAttributeName:[UIColor whiteColor]}];
        CGSize size = [attString boundingRectWithSize:CGSizeMake(kScreenWidth-30, 200) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading context:nil].size;
        topStoryView.label.frame = CGRectMake(15, 200-size.height, kScreenWidth-30, size.height);
        topStoryView.label.attributedText = attString;
        [topStoryView.label setBottom:240];
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:5.f target:self selector:@selector(nextStoryDisplay) userInfo:nil repeats:YES];
    
}

- (void)updateSubViewsOriginY:(CGFloat)value {
    
    NSInteger index = _scrollView.contentOffset.x/kScreenWidth;
    TopStoryView * tsv = [_scrollView viewWithTag:index+100];
    [_pageControl setBottom:260+value/2];
    [tsv.label setBottom:_pageControl.top];
     
}

- (void)nextStoryDisplay{
    //设置偏移量
    [_scrollView setContentOffset:CGPointMake(_scrollView.contentOffset.x+kScreenWidth, 0) animated:YES];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if ([scrollView isEqual:_scrollView]) {
        CGFloat offSetX = scrollView.contentOffset.x;
        //一共五张，如果往左滑动到第五张  再往左滑 转为第一张
        if (offSetX == 6*kScreenWidth) {
            _scrollView.contentOffset = CGPointMake(kScreenWidth, 0);
            _pageControl.currentPage = 0;
        }
        //如果往右滑动到了第一张  再往右滑 转为第5张
        else if (offSetX == 0){
            _scrollView.contentOffset = CGPointMake(5*kScreenWidth, 0);
            _pageControl.currentPage = 4;
        }
        else{
            _pageControl.currentPage = offSetX/kScreenWidth-1;
        }
    }
}

//停止减速时候执行，慢于停止拖拽DidEndDragging
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    //暂停5秒
    [_timer setFireDate:[NSDate dateWithTimeIntervalSinceNow:5.0]];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
