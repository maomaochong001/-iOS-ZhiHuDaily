//
//  HomeViewCell.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/15.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "HomeViewCell.h"
@interface HomeViewCell()
/** 内部的label */
@property (nonatomic,strong) UILabel * label;
@property (nonatomic,strong) UIImageView * imgView;
@property (nonatomic,strong) UIImageView * warnImageView;//标示多图的图片
@end


@implementation HomeViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        // label
        _label = ({
            UILabel * label = [[UILabel alloc]init];
            label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            label.textColor = [UIColor blackColor];
            
            label.font = [UIFont fontWithName:@".PingFangSC-Regular" size:16];
            label.numberOfLines = 0;
            [self.contentView addSubview:label];
            label;
        });
        
        _imgView = ({
            UIImageView  * imageView = [[UIImageView alloc]init];
            [self.contentView addSubview:imageView];
            imageView;
        });
        
        _warnImageView = ({
            UIImageView  * imageView = [[UIImageView alloc]init];
            [_imgView addSubview:imageView];
            imageView;
        });
        
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [_imgView setMj_h:59];
    [_imgView setMj_w:72];
    [_imgView setMj_x:kScreenWidth-10-_imgView.mj_w];
    [_imgView setMj_y:14];
    
    [_warnImageView setMj_w:32];
    [_warnImageView setMj_h:14];
    [_warnImageView setMj_x:_imgView.mj_w-32];
    [_warnImageView setMj_y:_imgView.mj_h-14];
    
    [_label mas_makeConstraints:^(MASConstraintMaker * make) {
        make.left.equalTo(self.mas_left).offset(10);
        make.top.equalTo(self.mas_top).offset(14);
        make.bottom.equalTo(self.mas_bottom).offset(-14);
        make.right.equalTo(_imgView.mas_left).offset(-10);
    }];
}

- (void)settingData:(StoryInfo *)storyInfo
{
    self.label.text = storyInfo.title;
    if (storyInfo.images) {
        NSString *imageURL = [storyInfo.images firstObject];
        [self.imgView sd_setImageWithURL:[NSURL URLWithString:imageURL]];
    }
    if (storyInfo.multipic) {
        if (self.warnImageView.image == nil) {
            self.warnImageView.image = [UIImage imageNamed:@"Home_Morepic"];
        }
        self.warnImageView.hidden = NO;
    }else{
        self.warnImageView.hidden = YES;
    }
    
        StoryInfo * sInfo2 = [StoryInfo findFirstByCriteria:[NSString stringWithFormat:@"WHERE id=%ld",(long)storyInfo.id]];
        if (sInfo2.readAlready==1) {
            //已经读过此条
            self.label.textColor = [UIColor colorWithRed:0.404 green:0.404 blue:0.404 alpha:1.00];
        }
        else{
            self.label.textColor = [UIColor colorWithRed:0.000 green:0.000 blue:0.000 alpha:1.00];
        }
        

}


@end
