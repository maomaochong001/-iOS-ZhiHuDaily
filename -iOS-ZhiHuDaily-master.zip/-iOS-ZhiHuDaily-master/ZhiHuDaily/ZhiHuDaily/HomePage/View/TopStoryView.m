//
//  TopStoryView.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/1/8.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "TopStoryView.h"

@implementation TopStoryView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 300)];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        [self addSubview:imageView];
        _imageView = imageView;
        
        UILabel * label = [[UILabel  alloc]init];
        label.numberOfLines = 0;
        [self addSubview:label];
        _label = label;
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
