//
//  HttpOperation.m
//  HPYZhiHuDaily
//
//  Created by 洪鹏宇 on 15/11/5.
//  Copyright © 2015年 洪鹏宇. All rights reserved.
//

#import "HttpOperation.h"
#import "JSONKit.h"
#import "NSDictionary+JSON.h"
@implementation HttpOperation

+ (void)getRequestWithURL:(NSString *)URLString parameters:(id)parameters className:(NSString *)class success:(successBlock)success failure:(failureBlock)failure {
    NSLog(@"URLString:%@",URLString);
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[NSURL URLWithString:BASEURL]];
    [manager GET:URLString parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        if (success) {
            
            NSString * jsonStr = [HttpOperation dictionaryToJson:(NSDictionary*)responseObject];
            NSLog(@"jsonStr:    %@",jsonStr);
            if ([HttpOperation isValidJsonStr:jsonStr]) {
                success([HttpOperation decodeJsonStr:jsonStr withClsName:class]);
                
            }
            
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

#pragma mark -
#pragma mark - 解析数据结构
/*
 JSON 判断是否为json
 param: jsonStr原字符串
 */
+ (BOOL)isValidJsonStr:(NSString*)jsonStr {
    NSDictionary* dic = nil;
    double version = [[UIDevice currentDevice].systemVersion doubleValue];//判定系统版本。
    if(version>=5.0f){
        NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
        NSError *error = nil;
        dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves  error:&error];
    }
    else {
        dic = [jsonStr objectFromJSONString];
    }
    if([dic allKeys] != 0) {
        return YES;
    }
    return NO;
}
/*
 JSON 解析函数
 param: clsName为解析后，所要得到的class类型名
 */
+ (id)decodeJsonStr:(NSString*)jsonStr
       withClsName:(NSString*)clsName {
    NSDictionary* dic = nil;
    double version = [[UIDevice currentDevice].systemVersion doubleValue];//判定系统版本。
    if(version>=5.0f){
        NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
        
        NSError *error = nil;
        
        dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves  error:&error];
    }
    else {
        dic = [jsonStr objectFromJSONString];
    }
    // 没有对象的解析时 直接返回数据
    if(!clsName || clsName.length == 0){
        return dic;
    }
    // 数据转换成对象
    Class retClass = NSClassFromString(clsName);
    
    retClass = [dic dictionaryTo:retClass];
    return retClass;
}
//字典转化为字符串
+ (NSString*)dictionaryToJson:(NSDictionary *)dic
{
    NSError *parseError = nil;
    NSData  *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}
@end
