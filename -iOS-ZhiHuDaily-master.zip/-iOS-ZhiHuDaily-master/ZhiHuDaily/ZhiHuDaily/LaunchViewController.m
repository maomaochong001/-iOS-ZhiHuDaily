//
//  LaunchViewController.m
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/22.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "LaunchViewController.h"
@interface LaunchViewController ()
@property (nonatomic, strong)UIImageView    * launchImage;
@property (nonatomic, strong)UIImageView    * logoImage;
@property (nonatomic, strong)UILabel        * tittleLab;
@end

@implementation LaunchViewController
- (void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.141 green:0.165 blue:0.188 alpha:1.00];
    [self.view addSubview:self.launchImage];
   
    [self updateLaunchImage];
}

- (void)updateLaunchImage{
    //[self.view addSubview:self.logoImage];
    //[self.view addSubview:self.tittleLab];
    
    //self.tittleLab.text = [responseObject objectForKey:@"text"];
    [UIView animateWithDuration:3.0f animations:^{
        self.launchImage.alpha = 0.5f;
        self.launchImage.transform = CGAffineTransformMakeScale(1.2, 1.2);
    } completion:^(BOOL finished) {
        [self.view removeFromSuperview];
    }];
    /*
    [HttpOperation getRequestWithURL:@"http://news-at.zhihu.com/api/4/start-image/720*1184" parameters:nil className:@"" success:^(id responseObject) {
        
        [self.launchImage sd_setImageWithURL:[NSURL URLWithString:[responseObject objectForKey:@"img"]] placeholderImage:[UIImage imageNamed:@"Default"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            [self.view addSubview:self.logoImage];
            [self.view addSubview:self.tittleLab];
            self.tittleLab.text = [responseObject objectForKey:@"text"];
                    [UIView animateWithDuration:3.0f animations:^{
                        self.launchImage.alpha = 0.5f;
                        self.launchImage.transform = CGAffineTransformMakeScale(1.2, 1.2);
                    } completion:^(BOOL finished) {
                        [self.view removeFromSuperview];
                    }];
        }];

    } failure:nil];
    */
}


- (UIImageView *)launchImage{
    if (_launchImage == nil) {
        _launchImage = [[UIImageView alloc]initWithFrame:kScreenBounds];
        _launchImage.image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Splash_Image@2x" ofType:@"jpg"]];
    }
    return _launchImage;
}

- (UIImageView *)logoImage{
    if (_logoImage == nil) {
         _logoImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kWidth(128), kHeight(49))];
        _logoImage.image = [UIImage imageNamed:@"Login_Logo"];
        [_logoImage setBottom:kScreenHeight-30];
        [_logoImage setCenterX:kScreenWidth/2];
    }
    return _logoImage;
}

- (UILabel *)tittleLab{
    if (_tittleLab == nil) {
        _tittleLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 120, 25)];
        _tittleLab.textColor = [UIColor colorWithRed:0.341 green:0.345 blue:0.349 alpha:1.00];
        _tittleLab.textAlignment = NSTextAlignmentCenter;
        _tittleLab.font = [UIFont systemFontOfSize:13];
        [_tittleLab setCenterX:kScreenWidth/2];
        [_tittleLab setBottom:kScreenHeight-5];
    }
    return _tittleLab;
}
@end
