//
//  ThemeItemCell.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/3/7.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
@interface ThemeItemCell : UITableViewCell
@property (nonatomic,strong) UILabel * label;
@property (nonatomic,strong) UIImageView * imgView;
- (void)settingData:(StoryInfo *)themeItem;
@end
