//
//  MyFavouriteViewController.h
//  ZhiHuDaily
//
//  Created by zemengli on 16/5/20.
//  Copyright © 2016年 zemengli. All rights reserved.
//

#import "BaseViewController.h"

@interface MyFavouriteViewController : BaseViewController

@end
